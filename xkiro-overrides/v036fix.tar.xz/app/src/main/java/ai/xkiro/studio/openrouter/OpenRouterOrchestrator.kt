package ai.xkiro.studio.openrouter

import android.content.Context
import ai.xkiro.studio.core.StudioSettings
import ai.xkiro.studio.memory.SharedAgentMemory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

object OpenRouterOrchestrator {
    private data class CatalogCache(val at: Long, val models: List<OpenRouterModel>)
    private enum class Tier { FAST, BALANCED, DEEP }
    private data class RouteDecision(
        val tier: Tier,
        val agents: Int,
        val needsCode: Boolean,
        val needsVision: Boolean,
        val reason: String
    )

    private val cache = ConcurrentHashMap<Int, CatalogCache>()
    private val routeCache = ConcurrentHashMap<String, Pair<Long, RouteDecision>>()
    private const val CACHE_MS = 15 * 60 * 1000L
    private const val ROUTE_CACHE_MS = 10 * 60 * 1000L

    private suspend fun models(key: String): List<OpenRouterModel> {
        val id = key.hashCode()
        val now = System.currentTimeMillis()
        cache[id]?.takeIf { now - it.at < CACHE_MS }?.let { return it.models }
        val list = withContext(Dispatchers.IO) { OpenRouterClient.listModels(key) }
        cache[id] = CatalogCache(now, list)
        return list
    }

    private fun baseScore(m: OpenRouterModel): Int {
        val s = (m.id + " " + m.name).lowercase()
        var score = 0
        val weights = mapOf(
            "astra" to 25, "sol" to 22, "opus" to 20, "sonnet" to 18,
            "terra" to 17, "claude" to 15, "gemini" to 15, "gpt" to 14,
            "deepseek" to 12, "qwen" to 9, "mistral" to 8,
            "flash" to 5, "luna" to 7, "mini" to -2
        )
        weights.forEach { (k, v) -> if (k in s) score += v }
        if (m.contextLength >= 256_000) score += 3 else if (m.contextLength >= 128_000) score += 2
        if (m.id.endsWith(":free")) score -= 2
        return score
    }

    private fun pricedOrFree(m: OpenRouterModel): Boolean =
        m.id.endsWith(":free") || (m.promptPricePerToken > 0.0 && m.completionPricePerToken > 0.0)

    private fun isInteractive(m: OpenRouterModel): Boolean {
        val s = (m.id + " " + m.name).lowercase()
        return !listOf(":batch", "batch-only", "batch only").any { it in s }
    }

    private fun textModels(all: List<OpenRouterModel>) = all
        .filter { it.textOutput && "text" in it.inputModalities }
        .filter(::pricedOrFree)
        .filter(::isInteractive)

    private fun cheapTextCandidates(all: List<OpenRouterModel>): List<OpenRouterModel> = textModels(all)
        .filter { it.promptUsdPerMillion <= 0.75 && it.completionUsdPerMillion <= 4.0 }
        .sortedWith(compareByDescending<OpenRouterModel> { baseScore(it) }.thenBy { it.promptUsdPerMillion + it.completionUsdPerMillion })

    private fun balancedCandidates(all: List<OpenRouterModel>): List<OpenRouterModel> = textModels(all)
        .filter { it.promptUsdPerMillion <= 2.5 && it.completionUsdPerMillion <= 14.0 }
        .sortedWith(compareByDescending<OpenRouterModel> { baseScore(it) }.thenBy { it.promptUsdPerMillion + it.completionUsdPerMillion })

    private fun strongCandidates(all: List<OpenRouterModel>): List<OpenRouterModel> = textModels(all)
        .filter { it.promptUsdPerMillion <= 6.0 && it.completionUsdPerMillion <= 30.0 }
        .sortedWith(compareByDescending<OpenRouterModel> { baseScore(it) }.thenBy { it.promptUsdPerMillion + it.completionUsdPerMillion })

    private fun codeCandidates(all: List<OpenRouterModel>, tier: Tier = Tier.BALANCED): List<OpenRouterModel> {
        val base = when (tier) {
            Tier.FAST -> cheapTextCandidates(all) + balancedCandidates(all)
            Tier.BALANCED -> balancedCandidates(all) + strongCandidates(all)
            Tier.DEEP -> strongCandidates(all) + balancedCandidates(all)
        }
        return base.distinctBy { it.id }.sortedWith(compareByDescending<OpenRouterModel> {
            val s = (it.id + " " + it.name).lowercase()
            baseScore(it) + if (listOf("coder", "code", "codex", "deepseek", "gpt", "gemini", "claude", "qwen").any(s::contains)) 14 else 0
        }.thenBy { it.promptUsdPerMillion + it.completionUsdPerMillion })
    }

    private fun visionCandidates(all: List<OpenRouterModel>, tier: Tier = Tier.BALANCED): List<OpenRouterModel> {
        val maxIn = when (tier) { Tier.FAST -> 1.0; Tier.BALANCED -> 3.0; Tier.DEEP -> 6.0 }
        val maxOut = when (tier) { Tier.FAST -> 5.0; Tier.BALANCED -> 16.0; Tier.DEEP -> 30.0 }
        return all.filter { it.vision && it.textOutput }
            .filter(::pricedOrFree)
            .filter(::isInteractive)
            .filter { it.promptUsdPerMillion <= maxIn && it.completionUsdPerMillion <= maxOut }
            .sortedWith(compareByDescending<OpenRouterModel> {
                val s = (it.id + " " + it.name).lowercase()
                baseScore(it) + if (listOf("vision", "gemini", "gpt", "claude", "flash").any(s::contains)) 7 else 0
            }.thenBy { it.promptUsdPerMillion + it.completionUsdPerMillion })
    }

    private fun candidatesFor(all: List<OpenRouterModel>, route: RouteDecision): List<OpenRouterModel> = when {
        route.needsCode -> codeCandidates(all, route.tier)
        route.tier == Tier.FAST -> (cheapTextCandidates(all) + balancedCandidates(all)).distinctBy { it.id }
        route.tier == Tier.BALANCED -> (balancedCandidates(all) + strongCandidates(all)).distinctBy { it.id }
        else -> (strongCandidates(all) + balancedCandidates(all)).distinctBy { it.id }
    }

    private fun localComplexity(request: String, mode: String): Int {
        val t = request.lowercase()
        var score = 0
        if (request.length > 450) score++
        if (request.length > 1200) score += 2
        if (request.length > 3000) score += 2
        val heavy = listOf(
            "completo", "complexo", "grande", "do zero", "arquitetura", "refator", "debug", "corrij",
            "projeto", "muitos arquivos", "vários arquivos", "varios arquivos", "apk", "compila", "build",
            "autônomo", "autonomo", "multiagente", "múltiplos agentes", "multiplos agentes", "analise tudo",
            "melhore ao máximo", "melhorar ao máximo", "work", "minecraft", "backend", "frontend"
        )
        score += heavy.count { it in t }.coerceAtMost(5)
        if (mode == "work") score += 2
        if (mode == "code" && request.length > 500) score++
        if (mode == "device" && request.length < 180 && listOf("abra ", "toque ", "clique ", "digite ", "volte", "enter").any { it in t }) score -= 2
        return score.coerceAtLeast(0)
    }

    private fun fallbackRoute(request: String, mode: String, settings: StudioSettings): RouteDecision {
        val t = request.lowercase()
        val score = localComplexity(request, mode)
        val tier = when {
            score >= 6 -> Tier.DEEP
            score >= 3 -> Tier.BALANCED
            else -> Tier.FAST
        }
        var agents = when (tier) { Tier.FAST -> 1; Tier.BALANCED -> 2; Tier.DEEP -> 3 }
        if (settings.openRouterTaskBudgetUsd < 0.08) agents = 1
        else if (settings.openRouterTaskBudgetUsd < 0.16) agents = minOf(agents, 2)
        if (mode == "device") agents = minOf(agents, 2)
        return RouteDecision(
            tier = tier,
            agents = agents,
            needsCode = mode in setOf("code", "work") || listOf("código", "codigo", "python", "java", "kotlin", "html", "css", "javascript", "program").any { it in t },
            needsVision = mode == "device" || listOf("tela", "screenshot", "print", "imagem").any { it in t },
            reason = "análise local de complexidade=$score"
        )
    }

    private suspend fun decideRoute(context: Context, settings: StudioSettings, request: String, mode: String): RouteDecision {
        val cacheKey = "${settings.openRouterKey.hashCode()}|$mode|${request.trim().lowercase().hashCode()}|${settings.openRouterTaskBudgetUsd}"
        val now = System.currentTimeMillis()
        routeCache[cacheKey]?.takeIf { now - it.first < ROUTE_CACHE_MS }?.let { return it.second }

        val fallback = fallbackRoute(request, mode, settings)
        // Obvious tiny or very large requests do not need a paid router call.
        val complexity = localComplexity(request, mode)
        if (complexity <= 1 || complexity >= 7) {
            routeCache[cacheKey] = now to fallback
            return fallback
        }

        val all = models(settings.openRouterKey)
        val routerCandidates = cheapTextCandidates(all)
        if (routerCandidates.isEmpty()) {
            routeCache[cacheKey] = now to fallback
            return fallback
        }
        val sys = """
            Você é o roteador econômico de um sistema multiagente. Classifique o pedido sem executá-lo.
            Retorne SOMENTE JSON: {"tier":"fast|balanced|deep","agents":1,"needs_code":false,"needs_vision":false,"reason":"curto"}.
            Use 1 agente para tarefas simples, 2 para médias e até 3 para projetos grandes/ambíguos que se beneficiem de revisão independente.
            Não peça 3 agentes para ações simples de celular. Preserve orçamento.
        """.trimIndent()
        val raw = runCatching {
            callText(context, settings, routerCandidates, sys, "MODO=$mode\nPEDIDO=${request.take(2600)}", 170, 0.0).text
        }.getOrNull()
        val routed = raw?.let { parseRoute(it, fallback, settings, mode) } ?: fallback
        routeCache[cacheKey] = now to routed
        return routed
    }

    private fun parseRoute(raw: String, fallback: RouteDecision, settings: StudioSettings, mode: String): RouteDecision {
        val start = raw.indexOf('{'); val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return fallback
        return runCatching {
            val o = JSONObject(raw.substring(start, end + 1))
            val tier = when (o.optString("tier").lowercase()) {
                "deep" -> Tier.DEEP
                "balanced" -> Tier.BALANCED
                else -> Tier.FAST
            }
            var agents = o.optInt("agents", when (tier) { Tier.FAST -> 1; Tier.BALANCED -> 2; Tier.DEEP -> 3 }).coerceIn(1, 3)
            if (settings.openRouterTaskBudgetUsd < 0.08) agents = 1
            else if (settings.openRouterTaskBudgetUsd < 0.16) agents = minOf(agents, 2)
            if (mode == "device") agents = minOf(agents, 2)
            RouteDecision(
                tier,
                agents,
                o.optBoolean("needs_code", fallback.needsCode),
                o.optBoolean("needs_vision", fallback.needsVision),
                o.optString("reason", fallback.reason).take(180)
            )
        }.getOrDefault(fallback)
    }

    suspend fun status(context: Context, settings: StudioSettings): String {
        val key = settings.openRouterKey
        require(key.isNotBlank()) { "Coloque sua OpenRouter API key." }
        val all = models(key)
        val fast = cheapTextCandidates(all).firstOrNull()
        val balanced = balancedCandidates(all).firstOrNull()
        val deep = strongCandidates(all).firstOrNull()
        val vision = visionCandidates(all, Tier.BALANCED).take(2)
        val keyInfo = runCatching { withContext(Dispatchers.IO) { OpenRouterClient.getKeyInfo(key) } }.getOrNull()
        val remaining = keyInfo?.limitRemaining?.let { " • limite restante da chave: US$ %.2f".format(it) }.orEmpty()
        val spent = OpenRouterBudget.spentToday(context)
        val memory = runCatching { SharedAgentMemory.stats(context) }.getOrNull()
        return buildString {
            append("OpenRouter: ${all.size} modelos • gasto local hoje US$ %.4f / US$ %.2f".format(spent, settings.openRouterDailyBudgetUsd))
            append(remaining)
            append("\nRouter automático: decide dificuldade + 1/2/3 modelos por pedido")
            append("\nRápido atual: ${fast?.id ?: "não encontrado"}")
            append("\nEquilibrado atual: ${balanced?.id ?: "não encontrado"}")
            append("\nProfundo atual: ${deep?.id ?: "não encontrado"}")
            append("\nVisão: ${vision.joinToString { it.id }.ifBlank { "não encontrada" }}")
            append("\nxKiro fica como fallback quando configurado.")
            memory?.let { append("\nMemória: ${it.total} registros • ${it.shared} compartilhados • ${it.agentSpecific} por agente") }
        }
    }

    suspend fun adaptiveChat(context: Context, settings: StudioSettings, system: String, user: String, maxTokens: Int = 1600, temperature: Double = 0.16): String {
        val route = decideRoute(context, settings, user, "general")
        val all = models(settings.openRouterKey)
        val memory = SharedAgentMemory.relevant(context, user, "Main Agent", 5, 3600)
        val sys = appendMemory(system, memory)
        val result = adaptiveText(context, settings, all, route, sys, user, maxTokens, temperature)
        runCatching { SharedAgentMemory.rememberExchange(context, "Main Agent", user, result, "conversation", true, 0.64) }
        return result
    }


    suspend fun webResearch(context: Context, settings: StudioSettings, question: String): String {
        require(settings.openRouterKey.isNotBlank()) { "OpenRouter é necessário para pesquisa web." }
        val all = models(settings.openRouterKey)
        val toolCapable = (balancedCandidates(all) + strongCandidates(all) + cheapTextCandidates(all))
            .distinctBy { it.id }
            .filter { "tools" in it.supportedParameters || "tool_choice" in it.supportedParameters }
        val candidates = if (toolCapable.isNotEmpty()) toolCapable else balancedCandidates(all) + cheapTextCandidates(all)
        require(candidates.isNotEmpty()) { "Não encontrei modelo compatível para pesquisa." }

        var last: Throwable? = null
        val system = """
            Você é o Research Agent do xKiro AI Studio. Pesquise a internet somente quando necessário, use fontes atuais e confiáveis, compare informações conflitantes e inclua links/citações úteis na resposta. Seja econômico: faça poucas buscas e não pesquise de novo o que já estiver suficientemente sustentado. Responda em português do Brasil.
        """.trimIndent()
        val memory = SharedAgentMemory.relevant(context, question, "Research Agent", 4, 2600)
        val sys = appendMemory(system, memory)
        for (m in candidates.take(8)) {
            val estimated = OpenRouterBudget.estimate(m, sys.length + question.length, 1500, false) + 0.01
            if (estimated > settings.openRouterTaskBudgetUsd) continue
            try {
                OpenRouterBudget.requireAllowed(context, settings, estimated)
                val r = withContext(Dispatchers.IO) {
                    OpenRouterClient.webResearchChat(settings.openRouterKey, m.id, sys, question, 1500, 0.08, 5)
                }
                OpenRouterBudget.record(context, r.costUsd)
                if (r.text.isNotBlank()) {
                    runCatching { SharedAgentMemory.rememberExchange(context, "Research Agent", question, r.text, "web_research", true, 0.74) }
                    return r.text
                }
            } catch (t: Throwable) {
                last = t
                if (t is IllegalStateException && t.message.orEmpty().startsWith("Proteção de gasto")) throw t
            }
        }
        throw last ?: IllegalStateException("A pesquisa web não coube no limite de custo desta tarefa.")
    }
    suspend fun fastChat(context: Context, settings: StudioSettings, system: String, user: String, maxTokens: Int = 700, temperature: Double = 0.2): String {
        val all = models(settings.openRouterKey)
        val memory = SharedAgentMemory.relevant(context, user, "Fast Agent", 4, 2800)
        val sys = appendMemory(system, memory)
        return callText(context, settings, cheapTextCandidates(all) + balancedCandidates(all), sys, user, maxTokens, temperature).text
    }

    suspend fun balancedChat(context: Context, settings: StudioSettings, system: String, user: String, maxTokens: Int = 1400, temperature: Double = 0.15): String =
        adaptiveChat(context, settings, system, user, maxTokens, temperature)

    suspend fun codeChat(context: Context, settings: StudioSettings, system: String, user: String, maxTokens: Int = 2200, temperature: Double = 0.08): String {
        val route = decideRoute(context, settings, user, "code")
        val all = models(settings.openRouterKey)
        val memory = SharedAgentMemory.relevant(context, user, "Code Agent", 6, 4200)
        val sys = appendMemory(system, memory)
        val result = adaptiveText(context, settings, all, route.copy(needsCode = true), sys, user, maxTokens, temperature)
        runCatching { SharedAgentMemory.rememberExchange(context, "Code Agent", user, result, "code_solution", false, 0.68) }
        return result
    }

    private suspend fun adaptiveText(
        context: Context,
        settings: StudioSettings,
        all: List<OpenRouterModel>,
        route: RouteDecision,
        system: String,
        user: String,
        maxTokens: Int,
        temperature: Double
    ): String = coroutineScope {
        val candidates = candidatesFor(all, route)
        require(candidates.isNotEmpty()) { "Não encontrei modelo OpenRouter compatível com esta tarefa." }
        if (route.agents <= 1) return@coroutineScope callText(context, settings, candidates, system, user, maxTokens, temperature).text

        val team = diverseTeam(candidates, route.agents).filterAffordable(settings, system.length + user.length, maxTokens)
        if (team.size <= 1) return@coroutineScope callText(context, settings, candidates, system, user, maxTokens, temperature).text

        val drafts = team.mapIndexed { idx, model ->
            async(Dispatchers.IO) {
                runCatching {
                    callText(context, settings, listOf(model), "$system\n\nVocê é o agente ${idx + 1}/${team.size}. Resolva independentemente e aponte incertezas.", user, maxTokens, temperature).text
                }.getOrNull()
            }
        }.awaitAll().filterNotNull().filter { it.isNotBlank() }
        if (drafts.isEmpty()) return@coroutineScope callText(context, settings, candidates, system, user, maxTokens, temperature).text
        if (drafts.size == 1) return@coroutineScope drafts.first()

        val joined = drafts.mapIndexed { i, d -> "RESPOSTA ${i + 1}:\n${d.take(9000)}" }.joinToString("\n\n")
        val judgeSystem = "$system\n\nVocê é o integrador final. Combine apenas o que estiver bem sustentado, corrija conflitos e entregue uma única resposta final."
        return@coroutineScope runCatching {
            callText(context, settings, candidates, judgeSystem, "PEDIDO ORIGINAL:\n$user\n\n$joined", maxTokens, 0.05).text
        }.getOrElse { drafts.first() }
    }

    private fun List<OpenRouterModel>.filterAffordable(settings: StudioSettings, inputChars: Int, maxTokens: Int): List<OpenRouterModel> {
        val cap = settings.openRouterTaskBudgetUsd * 0.72
        var sum = 0.0
        val out = mutableListOf<OpenRouterModel>()
        for (m in this) {
            val e = OpenRouterBudget.estimate(m, inputChars, maxTokens, false)
            if (e <= 0.0 || sum + e <= cap) {
                out += m
                sum += e.coerceAtLeast(0.0)
            }
        }
        return out
    }

    private suspend fun callText(
        context: Context,
        settings: StudioSettings,
        candidates: List<OpenRouterModel>,
        system: String,
        user: String,
        maxTokens: Int,
        temperature: Double
    ): OpenRouterResult {
        require(settings.openRouterKey.isNotBlank()) { "OpenRouter API key não configurada." }
        var last: Throwable? = null
        for (m in candidates.distinctBy { it.id }.take(12)) {
            val estimated = OpenRouterBudget.estimate(m, system.length + user.length, maxTokens, false)
            if (estimated > settings.openRouterTaskBudgetUsd) continue
            try {
                OpenRouterBudget.requireAllowed(context, settings, estimated)
                val r = withContext(Dispatchers.IO) { OpenRouterClient.chat(settings.openRouterKey, m.id, system, user, maxTokens, temperature) }
                OpenRouterBudget.record(context, r.costUsd)
                if (r.text.isNotBlank()) return r
            } catch (t: Throwable) {
                last = t
                if (t is IllegalStateException && t.message.orEmpty().startsWith("Proteção de gasto")) throw t
            }
        }
        throw last ?: IllegalStateException("Não encontrei um modelo OpenRouter dentro do seu limite de custo para esta chamada.")
    }

    suspend fun deviceTextPlan(
        context: Context,
        settings: StudioSettings,
        request: String,
        system: String,
        user: String,
        maxTokens: Int = 700
    ): String = coroutineScope {
        val route = decideRoute(context, settings, request, "device")
        val all = models(settings.openRouterKey)
        val candidates = candidatesFor(all, route.copy(needsCode = false))
        require(candidates.isNotEmpty()) { "Nenhum modelo de controle disponível." }
        if (route.agents <= 1) return@coroutineScope callText(context, settings, candidates, system, user, maxTokens, 0.0).text
        val team = diverseTeam(candidates, minOf(2, route.agents)).filterAffordable(settings, system.length + user.length, maxTokens)
        if (team.size <= 1) return@coroutineScope callText(context, settings, candidates, system, user, maxTokens, 0.0).text
        val plans = team.map { m ->
            async(Dispatchers.IO) { runCatching { callText(context, settings, listOf(m), system, user, maxTokens, 0.0).text }.getOrNull() }
        }.awaitAll().filterNotNull().filter { it.isNotBlank() }
        if (plans.size <= 1) return@coroutineScope plans.firstOrNull() ?: callText(context, settings, candidates, system, user, maxTokens, 0.0).text
        val judge = """
            PLANO A:
            ${plans[0].take(4500)}

            PLANO B:
            ${plans[1].take(4500)}

            Escolha ou combine o melhor. Retorne SOMENTE JSON no formato exigido pelo sistema.
        """.trimIndent()
        return@coroutineScope runCatching {
            val judgeSystem = """
                $system
                Você é o integrador final do Device Agent.
            """.trimIndent()
            callText(context, settings, candidates, judgeSystem, judge, maxTokens, 0.0).text
        }.getOrElse { plans.first() }
    }

    suspend fun describeScreen(context: Context, settings: StudioSettings, request: String, jpeg: ByteArray, accessibilitySnapshot: String): String = coroutineScope {
        val route = decideRoute(context, settings, request, "device")
        val all = models(settings.openRouterKey)
        val team = visionTeam(visionCandidates(all, route.tier), route)
        require(team.isNotEmpty()) { "Não encontrei modelo de visão econômico no OpenRouter." }
        val sys = "Analise a tela Android do usuário. Seja concreto, curto e não invente elementos. Considere também a árvore de acessibilidade."
        val memory = SharedAgentMemory.relevant(context, request, "Vision Agent", 3, 2200)
        val prompt = buildString {
            append("PEDIDO: $request\nÁRVORE:\n${accessibilitySnapshot.take(10000)}")
            if (memory.isNotBlank()) append("\n\n$memory")
        }
        val answers = team.map { m -> async(Dispatchers.IO) { runCatching { callVision(context, settings, m, sys, prompt, jpeg, 650) }.getOrNull()?.text } }
            .awaitAll().filterNotNull().filter { it.isNotBlank() }
        if (answers.isEmpty()) error("Os modelos de visão não conseguiram ler a tela.")
        if (answers.size == 1) return@coroutineScope answers.first()
        return@coroutineScope runCatching {
            fastChat(context, settings, "Você integra duas leituras da mesma tela. Remova contradições e responda objetivamente.", answers.joinToString("\n\n---\n\n"), 500, 0.0)
        }.getOrElse { answers.first() }
    }

    suspend fun screenVisionPlan(
        context: Context,
        settings: StudioSettings,
        request: String,
        accessibilitySnapshot: String,
        jpeg: ByteArray,
        round: Int
    ): String = coroutineScope {
        val route = decideRoute(context, settings, request, "device")
        val all = models(settings.openRouterKey)
        val visionTier = if (route.tier == Tier.DEEP || request.contains("ESTAGNAÇÃO", ignoreCase = true)) Tier.DEEP else Tier.BALANCED
        val pair = visionTeam(visionCandidates(all, visionTier), route, forceAccurate = true)
        require(pair.isNotEmpty()) { "Nenhum modelo OpenRouter com visão adequado coube no limite configurado." }
        val sys = """
            Você é o cérebro visual do xKiro Device Agent. Controle este Android como um humano olhando a tela. Não existem atalhos semânticos para abrir URL/app nem para clicar por texto/ID. Navegue fisicamente com Home/Back, taps, swipes, digitação e teclas Android. Execute exatamente UMA ação física e depois observe um frame novo antes de decidir a próxima.
            Retorne SOMENTE JSON válido: {"actions":[EXATAMENTE_UMA_ACAO],"message":"o que a ação fará, sem fingir resultado","confidence":0.0}.
            Ações permitidas: tap, double_tap, long_press, swipe, swipe_direction, drag, type_text, paste, enter, press_key, back, home, recents, wait, finish, need_confirmation.
            Gestos usam coordenadas da screenshot. A posição do último gesto pode aparecer no PEDIDO como CURSOR_XKIRO.
            Use a árvore de acessibilidade apenas como contexto para entender a tela; a interação deve acontecer pelas ações físicas permitidas acima.
            wait_for_text é apenas uma espera auxiliar: se o texto não aparecer, observe novamente e tente outra evidência visual; não trate isso sozinho como falha final.
            Faça somente 1 ação por quadro. Para texto, primeiro toque visualmente no campo e depois use type_text ou paste.
            Não invente sucesso. Se xKiro estiver em primeiro plano, use home e nunca toque nos controles do próprio xKiro. Só use wait com carregamento visível e não repita wait indefinidamente. finish só quando o frame ATUAL provar conclusão. Se a tela não mudou, mude de estratégia e não repita coordenadas.
        """.trimIndent()
        val memory = SharedAgentMemory.relevant(context, request, "Device Agent", 4, 2600)
        val prompt = buildString {
            append("PEDIDO: $request\nRODADA: $round\nROTA=${route.tier}/${route.agents} (${route.reason})\nÁRVORE:\n${accessibilitySnapshot.take(12000)}")
            if (memory.isNotBlank()) append("\n\n$memory")
        }
        val primaryModel = pair.first()
        val primary = runCatching { callVision(context, settings, primaryModel, sys, prompt, jpeg, 650).text }.getOrNull()
            ?.takeIf { it.isNotBlank() } ?: error("Falha ao analisar a tela no OpenRouter.")
        val primaryConfidence = extractConfidence(primary)
        val primarySig = actionSignature(primary)
        if (pair.size == 1 || (primaryConfidence >= 0.80 && primarySig.isNotBlank())) return@coroutineScope primary

        val second = runCatching { callVision(context, settings, pair[1], sys, prompt, jpeg, 650).text }.getOrNull()
            ?.takeIf { it.isNotBlank() } ?: return@coroutineScope primary
        if (primarySig.isNotBlank() && primarySig == actionSignature(second)) return@coroutineScope primary
        val judgePrompt = "PEDIDO: $request\nPLANO A:\n${primary.take(3500)}\nPLANO B:\n${second.take(3500)}\nEscolha ou combine o plano mais seguro e coerente. Retorne SOMENTE JSON no mesmo formato."
        return@coroutineScope runCatching {
            fastChat(context, settings, "Você é o juiz do Device Agent. Não invente ações fora dos planos e preserve confirmações para ações sensíveis.", judgePrompt, 520, 0.0)
        }.getOrElse { primary }
    }

    suspend fun repairWorkManifest(context: Context, settings: StudioSettings, repairPrompt: String): String {
        val all = models(settings.openRouterKey)
        val candidates = (codeCandidates(all, Tier.DEEP) + codeCandidates(all, Tier.BALANCED)).distinctBy { it.id }
        require(candidates.isNotEmpty()) { "Nenhum modelo disponível para reparar o Work." }
        val schema = """
            Você está reparando apenas o PLANO de um projeto do Work.
            Retorne somente linhas, sem Markdown:
            SUMMARY|resumo curto
            FILE|caminho/seguro.ext|finalidade concreta
            NOTE|nota opcional
            Máximo 16 arquivos. Não inclua conteúdo dos arquivos.
        """.trimIndent()
        return callText(context, settings, candidates, schema, repairPrompt, 1800, 0.0).text
    }

    private data class WorkConfig(
        val route: RouteDecision,
        val team: List<OpenRouterModel>,
        val requestedPower: String,
        val fileMaxTokens: Int,
        val temperature: Double
    )

    private suspend fun workConfig(
        context: Context,
        settings: StudioSettings,
        request: String,
        selectedModel: String,
        power: String
    ): WorkConfig {
        val automaticRoute = decideRoute(context, settings, request, "work")
        val requestedPower = power.uppercase()
        var route = when (requestedPower) {
            "WEAK" -> automaticRoute.copy(tier = Tier.FAST, agents = 1)
            "MEDIUM" -> automaticRoute.copy(tier = Tier.BALANCED, agents = 1)
            "HIGH" -> automaticRoute.copy(tier = Tier.BALANCED, agents = 2)
            "MAX" -> automaticRoute.copy(tier = Tier.DEEP, agents = 2)
            "ULTRA" -> automaticRoute.copy(tier = Tier.DEEP, agents = 3)
            else -> automaticRoute
        }
        val budgetAgents = when {
            settings.openRouterTaskBudgetUsd < 0.08 -> 1
            settings.openRouterTaskBudgetUsd < 0.16 -> minOf(route.agents, 2)
            else -> route.agents
        }
        route = route.copy(agents = budgetAgents.coerceIn(1, 3))

        val all = models(settings.openRouterKey)
        val candidates = codeCandidates(all, route.tier)
        require(candidates.isNotEmpty()) { "Não encontrei modelo de código econômico no OpenRouter." }
        val manualPrimary = selectedModel.takeIf { it.isNotBlank() && !it.equals("auto", true) }?.let { id ->
            all.firstOrNull { it.id == id && it.textOutput }
                ?: throw IllegalArgumentException("O modelo selecionado não está mais disponível no OpenRouter: $id")
        }
        val team = if (manualPrimary != null) {
            listOf(manualPrimary) + diverseTeam(candidates.filterNot { it.id == manualPrimary.id }, route.agents - 1)
        } else diverseTeam(candidates, route.agents)
        require(team.isNotEmpty()) { "Não encontrei modelo compatível para o Work." }

        val fileMaxTokens = when (requestedPower) {
            "WEAK" -> 2800
            "MEDIUM" -> 4400
            "HIGH" -> 5800
            "MAX" -> 7600
            "ULTRA" -> 9200
            else -> when (route.tier) { Tier.FAST -> 3200; Tier.BALANCED -> 5000; Tier.DEEP -> 7200 }
        }
        val temperature = when (requestedPower) {
            "MAX", "ULTRA" -> 0.03
            "HIGH" -> 0.04
            else -> 0.06
        }
        return WorkConfig(route, team, requestedPower, fileMaxTokens, temperature)
    }

    suspend fun workManifest(
        context: Context,
        settings: StudioSettings,
        request: String,
        selectedModel: String = "auto",
        power: String = "AUTO",
        status: (String) -> Unit = {}
    ): String = coroutineScope {
        val cfg = workConfig(context, settings, request, selectedModel, power)
        status("Modelo principal • ${cfg.team[0].name.take(38)}")
        status("Potência • ${cfg.requestedPower.lowercase().replaceFirstChar { it.titlecase() }} • ${cfg.team.size} agente(s)")

        val protocol = """
            Você é o arquiteto do modo Work da Diana.
            Planeje a estrutura, mas NÃO escreva o conteúdo dos arquivos ainda.
            Retorne SOMENTE linhas neste protocolo, sem Markdown e sem JSON:
            SUMMARY|resumo curto do projeto
            FILE|caminho/seguro.ext|finalidade concreta e dependências deste arquivo
            FILE|outro.ext|finalidade concreta
            NOTE|nota opcional
            Máximo 16 arquivos. Sem caminhos absolutos, sem .., sem base64/binários.
            Prefira dividir responsabilidades em arquivos coerentes para evitar arquivos gigantes.
        """.trimIndent()
        val memory = SharedAgentMemory.relevant(context, request, "Work Planner", 5, 3200)
        val system = appendMemory("""
            $protocol
            Rota: ${cfg.route.tier}; equipe ${cfg.team.size}; potência ${cfg.requestedPower}.
        """.trimIndent(), memory)
        status("Montando estrutura do projeto")
        val primary = callText(context, settings, listOf(cfg.team[0]), system, request, 1800, 0.04).text
        if (cfg.team.size == 1) {
            runCatching { SharedAgentMemory.rememberExchange(context, "Work Planner", request, primary.take(3500), "work_plan", false, 0.68) }
            return@coroutineScope primary
        }

        status("Revisando arquitetura • ${cfg.team.size - 1} revisão(ões)")
        val reviews = cfg.team.drop(1).mapIndexed { idx, model ->
            async(Dispatchers.IO) {
                runCatching {
                    callText(
                        context, settings, listOf(model),
                        "Você é um revisor de arquitetura. Aponte somente problemas concretos no plano: arquivos faltantes, redundâncias e dependências quebradas. Seja curto.",
                        """
                            PEDIDO:
                            $request

                            PLANO:
                            ${primary.take(9000)}
                        """.trimIndent(), 850, 0.0
                    ).text
                }.getOrNull()
            }
        }.awaitAll().filterNotNull().filter { it.isNotBlank() }
        if (reviews.isEmpty()) return@coroutineScope primary

        status("Fechando estrutura final")
        val reviewText = reviews.mapIndexed { i, r -> """
            REVISÃO ${i + 1}:
            ${r.take(2500)}
        """.trimIndent() }.joinToString("\n\n")
        val final = runCatching {
            callText(
                context, settings, listOf(cfg.team[0]), protocol,
                """
                    PEDIDO:
                    $request

                    PLANO INICIAL:
                    ${primary.take(9000)}

                    $reviewText

                    Refaça o PLANO final no protocolo exigido.
                """.trimIndent(),
                1900, 0.02
            ).text
        }.getOrElse { primary }
        runCatching { SharedAgentMemory.rememberExchange(context, "Work Planner", request, final.take(3500), "work_plan", false, 0.74) }
        return@coroutineScope final
    }

    suspend fun workFileContent(
        context: Context,
        settings: StudioSettings,
        request: String,
        plan: String,
        path: String,
        purpose: String,
        selectedModel: String = "auto",
        power: String = "AUTO",
        completedPaths: List<String> = emptyList()
    ): String {
        val cfg = workConfig(context, settings, request + "\nARQUIVO:$path", selectedModel, power)
        val system = """
            Você é o implementador do modo Work da Diana.
            Gere SOMENTE o conteúdo completo do arquivo solicitado, pronto para salvar diretamente no disco.
            Não use cercas Markdown. Não explique fora do arquivo.
            Preserve compatibilidade com o plano do projeto e com os arquivos já concluídos.
            Evite comentários, documentação e repetição desnecessários quando isso puder fazer a saída truncar.
            Se o arquivo ficar grande, ainda assim entregue uma versão completa e funcional; prefira código conciso a uma resposta cortada.
        """.trimIndent()
        val user = """
            PEDIDO ORIGINAL:
            $request

            PLANO:
            ${plan.take(14000)}

            ARQUIVO ALVO: $path
            FINALIDADE: $purpose
            JÁ CONCLUÍDOS: ${completedPaths.joinToString(", ").ifBlank { "nenhum" }}

            Entregue agora somente o conteúdo integral de $path.
        """.trimIndent()
        val result = callText(context, settings, listOf(cfg.team[0]), system, user, cfg.fileMaxTokens, cfg.temperature).text
        runCatching { SharedAgentMemory.rememberExchange(context, "Work File", "$request [$path]", result.take(2200), "work_file", false, 0.54) }
        return result
    }

    private fun appendMemory(system: String, memory: String): String = if (memory.isBlank()) system else """
        $system

        $memory
        Regra de memória: use somente os trechos realmente relacionados ao pedido atual. Se uma memória conflitar com o pedido atual ou com a tela atual, ignore a memória.
    """.trimIndent()

    private fun manifestSummary(raw: String): String = runCatching {
        val start = raw.indexOf('{'); val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return@runCatching raw.take(1600)
        val obj = JSONObject(raw.substring(start, end + 1))
        val files = obj.optJSONArray("files")
        val names = buildList {
            if (files != null) for (i in 0 until minOf(files.length(), 16)) {
                files.optJSONObject(i)?.optString("path")?.takeIf { it.isNotBlank() }?.let(::add)
            }
        }
        "Resumo: ${obj.optString("summary").take(700)}\nArquivos: ${names.joinToString(", ").take(900)}"
    }.getOrDefault(raw.take(1600))

    private suspend fun callVision(
        context: Context,
        settings: StudioSettings,
        model: OpenRouterModel,
        system: String,
        user: String,
        jpeg: ByteArray,
        maxTokens: Int
    ): OpenRouterResult {
        val estimated = OpenRouterBudget.estimate(model, system.length + user.length, maxTokens, true)
        OpenRouterBudget.requireAllowed(context, settings, estimated)
        val r = withContext(Dispatchers.IO) { OpenRouterClient.visionChat(settings.openRouterKey, model.id, system, user, jpeg, maxTokens, 0.0) }
        OpenRouterBudget.record(context, r.costUsd)
        return r
    }

    private fun visionTeam(candidates: List<OpenRouterModel>, route: RouteDecision, forceAccurate: Boolean = false): List<OpenRouterModel> {
        if (candidates.isEmpty()) return emptyList()
        val count = if (forceAccurate) 2 else when (route.tier) { Tier.FAST -> 1; Tier.BALANCED -> minOf(2, route.agents); Tier.DEEP -> minOf(2, route.agents) }
        return diverseTeam(candidates, count)
    }

    private fun diverseTeam(candidates: List<OpenRouterModel>, count: Int): List<OpenRouterModel> {
        if (candidates.isEmpty() || count <= 0) return emptyList()
        val out = mutableListOf<OpenRouterModel>()
        val providers = mutableSetOf<String>()
        for (m in candidates) {
            val p = m.id.substringBefore('/')
            if (out.isEmpty() || p !in providers) {
                out += m; providers += p
                if (out.size >= count) return out
            }
        }
        for (m in candidates) {
            if (out.none { it.id == m.id }) out += m
            if (out.size >= count) break
        }
        return out
    }

    private fun extractConfidence(raw: String): Double {
        val start = raw.indexOf('{'); val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return 0.0
        return runCatching { JSONObject(raw.substring(start, end + 1)).optDouble("confidence", 0.0) }.getOrDefault(0.0)
    }

    private fun actionSignature(raw: String): String {
        val start = raw.indexOf('{'); val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return ""
        return runCatching {
            val obj = JSONObject(raw.substring(start, end + 1))
            val a = obj.optJSONArray("actions")?.optJSONObject(0)
            listOf(a?.optString("action").orEmpty(), a?.optString("target").orEmpty(), a?.optString("app").orEmpty()).joinToString("|")
        }.getOrDefault("")
    }
}
