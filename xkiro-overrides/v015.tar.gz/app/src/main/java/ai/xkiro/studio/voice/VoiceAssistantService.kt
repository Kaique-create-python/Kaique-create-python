package ai.xkiro.studio.voice

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.ActivityCompat
import ai.xkiro.studio.core.AgentOrchestrator
import ai.xkiro.studio.core.SettingsStore
import ai.xkiro.studio.device.DeviceAgentController
import kotlinx.coroutines.*
import java.io.File
import java.util.Locale

class VoiceAssistantService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var recognizer: SpeechRecognizer? = null
    private lateinit var settings: SettingsStore
    private var localTts: TextToSpeech? = null
    @Volatile private var busy = false
    @Volatile private var isDestroyed = false
    private var conversationUntil = 0L

    override fun onCreate() {
        super.onCreate()
        settings = SettingsStore(this)
        localTts = TextToSpeech(this, this)
        val ch = NotificationChannel("voice", "AI Voice Mode", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        startForeground(21, Notification.Builder(this, "voice")
            .setContentTitle("xKiro Voice Mode")
            .setContentText("Ouvindo em segundo plano")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build())
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListening()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            localTts?.language = Locale("pt", "BR")
            localTts?.setSpeechRate(1.05f)
        }
    }

    private fun startListening() {
        if (isDestroyed || busy || !SpeechRecognizer.isRecognitionAvailable(this)) return
        if (recognizer == null) recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 650L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 400L)
        }
        runCatching { recognizer?.startListening(i) }
    }

    private fun process(text: String) {
        if (busy) return
        val cfg = settings.load()
        val heard = text.trim()
        val heardLower = heard.lowercase(Locale.ROOT)
        val wake = cfg.wakeWord.lowercase(Locale.ROOT).trim()
        val hasWake = wake.isNotBlank() && heardLower.contains(wake)
        val inConversation = System.currentTimeMillis() < conversationUntil
        if (!hasWake && !inConversation) {
            restartSoon(180)
            return
        }

        val command = if (hasWake) {
            val idx = heardLower.indexOf(wake)
            heard.substring((idx + wake.length).coerceAtMost(heard.length)).trim()
        } else heard

        conversationUntil = System.currentTimeMillis() + 30_000L
        if (command.isBlank()) {
            speak("Estou ouvindo.")
            return
        }
        if (command.equals("para", true) || command.equals("parar", true) || command.equals("pare", true)) {
            DeviceAgentController.cancelCurrent()
            speak("Parei.", stopAfter = true)
            return
        }
        if (cfg.xkiroKey.isBlank()) {
            speak("Configure a chave da xKiro no aplicativo primeiro.")
            return
        }

        busy = true
        runCatching { recognizer?.cancel() }
        scope.launch {
            val reply = runCatching {
                if (DeviceAgentController.looksLikeDeviceCommand(command)) {
                    DeviceAgentController.resetCancellation()
                    DeviceAgentController.execute(this@VoiceAssistantService, cfg.xkiroKey, command) { }.message
                } else {
                    val res = AgentOrchestrator.runSwarm(cfg.xkiroKey, "Responda de forma curta e natural ao comando de voz: $command", 2)
                    AgentOrchestrator.synthesize(cfg.xkiroKey, command, res).take(1400)
                }
            }.getOrElse { "Deu um erro: ${it.message ?: "erro desconhecido"}" }
            speak(reply)
        }
    }

    private fun speak(text: String, stopAfter: Boolean = false) {
        busy = true
        val cfg = settings.load()
        if (cfg.voiceKey.isNotBlank() && cfg.voiceId.isNotBlank()) {
            scope.launch(Dispatchers.IO) {
                val eleven = runCatching {
                    val f = File(cacheDir, "voice_reply_${System.nanoTime()}.mp3")
                    ElevenVoiceClient.synthesize(cfg.voiceKey, cfg.voiceId, text, f)
                }
                withContext(Dispatchers.Main) {
                    if (eleven.isSuccess) playFile(eleven.getOrThrow(), text, stopAfter)
                    else speakLocal(text, stopAfter)
                }
            }
        } else {
            speakLocal(text, stopAfter)
        }
    }

    private fun playFile(file: File, fallbackText: String, stopAfter: Boolean) {
        runCatching {
            MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener {
                    it.release()
                    file.delete()
                    afterSpeech(stopAfter)
                }
                setOnErrorListener { mp, _, _ ->
                    mp.release()
                    file.delete()
                    speakLocal("Não consegui reproduzir a voz online.", stopAfter)
                    true
                }
                prepare()
                start()
            }
        }.onFailure { speakLocal(fallbackText, stopAfter) }
    }

    private fun speakLocal(text: String, stopAfter: Boolean) {
        val tts = localTts
        if (tts == null) {
            afterSpeech(stopAfter)
            return
        }
        val utteranceId = "xkiro_${System.nanoTime()}"
        tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) { Handler(Looper.getMainLooper()).post { afterSpeech(stopAfter) } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { Handler(Looper.getMainLooper()).post { afterSpeech(stopAfter) } }
        })
        val r = tts.speak(text.take(1800), TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        if (r == TextToSpeech.ERROR) afterSpeech(stopAfter)
    }

    private fun afterSpeech(stopAfter: Boolean) {
        busy = false
        if (stopAfter) stopSelf() else restartSoon(180)
    }

    private fun restartSoon(delayMs: Long = 250L) {
        if (isDestroyed) return
        Handler(Looper.getMainLooper()).postDelayed({ if (!isDestroyed && !busy) startListening() }, delayMs)
    }

    override fun onDestroy() {
        isDestroyed = true
        busy = true
        runCatching { recognizer?.cancel() }
        recognizer?.destroy()
        localTts?.stop()
        localTts?.shutdown()
        scope.cancel()
        super.onDestroy()
    }

    override fun onResults(results: Bundle?) {
        val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!phrase.isNullOrBlank()) process(phrase) else restartSoon()
    }
    override fun onError(error: Int) { if (!busy) restartSoon(220) }
    override fun onReadyForSpeech(params: Bundle?) = Unit
    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() = Unit
    override fun onPartialResults(partialResults: Bundle?) = Unit
    override fun onEvent(eventType: Int, params: Bundle?) = Unit
    override fun onBind(intent: Intent?): IBinder? = null
}
