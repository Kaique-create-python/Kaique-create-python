package ai.xkiro.studio.device

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.atomic.AtomicLong

class StudioAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: StudioAccessibilityService? = null
    }

    private val serial = AtomicLong(0)

    override fun onServiceConnected() {
        instance = this
        serial.incrementAndGet()
    }

    override fun onInterrupt() = Unit

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event != null) serial.incrementAndGet()
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        serial.incrementAndGet()
        super.onDestroy()
    }

    fun eventSerial(): Long = serial.get()

    fun activePackage(): String = rootInActiveWindow?.packageName?.toString().orEmpty()

    fun snapshot(maxNodes: Int = 220): String {
        val root = rootInActiveWindow ?: return "(sem árvore de acessibilidade)"
        val dm = resources.displayMetrics
        val lines = mutableListOf("package=${root.packageName} class=${root.className} screen=${dm.widthPixels}x${dm.heightPixels}")
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || lines.size >= maxNodes) return
            val text = node.text?.toString()?.take(140).orEmpty()
            val desc = node.contentDescription?.toString()?.take(140).orEmpty()
            val id = node.viewIdResourceName.orEmpty()
            val r = Rect().also { node.getBoundsInScreen(it) }
            if (text.isNotBlank() || desc.isNotBlank() || id.isNotBlank() || node.isClickable || node.isEditable || node.isScrollable) {
                lines += "${"  ".repeat(depth.coerceAtMost(6))}${node.className} text=$text desc=$desc id=$id bounds=${r.left},${r.top},${r.right},${r.bottom} clickable=${node.isClickable} editable=${node.isEditable} scrollable=${node.isScrollable} focused=${node.isFocused}"
            }
            for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1)
        }
        walk(root, 0)
        return lines.joinToString("\n")
    }

    private fun allNodes(root: AccessibilityNodeInfo): Sequence<AccessibilityNodeInfo> = sequence {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val n = stack.removeLast()
            yield(n)
            for (i in n.childCount - 1 downTo 0) n.getChild(i)?.let(stack::add)
        }
    }

    private fun clickNode(node: AccessibilityNodeInfo, long: Boolean = false): Boolean {
        var cur: AccessibilityNodeInfo? = node
        val action = if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK
        while (cur != null) {
            val capable = if (long) cur.isLongClickable else cur.isClickable
            if (capable && cur.performAction(action)) return true
            cur = cur.parent
        }
        return node.performAction(action)
    }

    fun clickText(target: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = target.trim()
        if (q.isBlank()) return false
        val exactish = root.findAccessibilityNodeInfosByText(q).firstOrNull()
        if (exactish != null && clickNode(exactish)) return true
        val lower = q.lowercase()
        val byDesc = allNodes(root).firstOrNull {
            it.contentDescription?.toString()?.lowercase()?.let { d -> d == lower || d.contains(lower) } == true
        }
        return byDesc?.let(::clickNode) ?: false
    }

    fun clickAny(vararg candidates: String): Boolean = candidates.any { clickText(it) }

    fun longClickText(target: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = target.trim()
        if (q.isBlank()) return false
        val node = root.findAccessibilityNodeInfosByText(q).firstOrNull() ?: return false
        return clickNode(node, true)
    }

    fun setFocusedText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (target == null || !target.isEditable) {
            target = allNodes(root).firstOrNull { it.isEditable }
        }
        target ?: return false
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun scrollableNode(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        return allNodes(root).firstOrNull { it.isScrollable }
    }

    fun scrollForward(): Boolean = scrollableNode()?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) ?: false
    fun scrollBackward(): Boolean = scrollableNode()?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) ?: false

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 55))
            .build()
        return dispatchGesture(g, null, null)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 220): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, durationMs.coerceIn(80, 1200)))
            .build()
        return dispatchGesture(g, null, null)
    }
}
