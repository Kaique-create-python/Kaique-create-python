package ai.xkiro.studio.device

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import ai.xkiro.studio.core.AgentOrchestrator
import ai.xkiro.studio.core.XKiroClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Base64
import java.util.Locale

object DeviceAgentController {
    @Volatile private var cancelRequested: Boolean = false
    @Volatile private var cachedPlannerModel: String? = null
    @Volatile private var cachedPlannerKeyHash: Int = 0
    @Volatile private var cachedPlannerUntil: Long = 0L

    fun resetCancellation() { cancelRequested = false }
    fun cancelCurrent() { cancelRequested = true }
    private fun cancelled(): Boolean = cancelRequested || Thread.currentThread().isInterrupted

    data class Result(val message: String, val actedOnDevice: Boolean)

    fun looksLikeDeviceCommand(text: String): Boolean {
        val t = text.lowercase(Locale.ROOT)
        val deviceWords = listOf(
            "abra ", "abre ", "abrir ", "entre no", "entra no", "vá para", "vai para",
            "no meu celular", "no meu cll", "meu celular", "mexer no celular", "mexa no",
            "termux", "whatsapp", "youtube", "configurações", "configuracoes", "chrome",
            "digite ", "escreva ", "toque em", "clique em", "aperte ", "pressione ",
            "dá enter", "da enter", "de enter", "volta", "voltar", "tela inicial", "home",
            "role ", "rolar ", "desce", "sobe", "notificações", "notificacoes", "recentes"
        )
        return deviceWords.any { it in t }
    }

    suspend fun execute(context: Context, apiKey: String, command: String, status: (String) -> Unit): Result {
        if (cancelled()) return Result("Tarefa interrompida por você.", false)
        val lower = command.lowercase(Locale.ROOT).trim()
        status("Device Agent: executando…")

        val service = StudioAccessibilityService.instance
        fastLocalAction(context, lower, command, service, status)?.let { return it }

        if ("termux" in lower && listOf("program", "crie", "cria", "faça", "faca", "script", "python", "ia ").any { it in lower }) {
            return executeTermux(context, apiKey, command, status)
        }

        if (service == null) {
            return Result("Ative o Device Agent em Acessibilidade para eu poder executar comandos no celular.", false)
        }

        val explicitApp = extractRequestedApp(lower)
        if (explicitApp != null && containsOpenVerb(lower)) {
            val packageName = findLaunchablePackage(context, explicitApp)
            if (packageName != null) {
                val serial = service.eventSerial()
                status("Device Agent: abrindo $explicitApp…")
                openPackage(context, packageName)
                waitForUiChange(service, serial, 500)
                val remainderSignals = listOf(" e ", " depois ", "pesquise", "digite", "escreva", "toque", "clique", "faça", "faca")
                if (remainderSignals.none { it in lower }) return Result("$explicitApp aberto.", true)
            }
        }

        return runScreenDrivenLoop(context, apiKey, command, status)
    }

    private suspend fun fastLocalAction(
        context: Context,
        lower: String,
        original: String,
        service: StudioAccessibilityService?,
        status: (String) -> Unit
    ): Result? {
        val onlyApp = extractRequestedApp(lower)
        if (onlyApp != null && containsOpenVerb(lower) && listOf(" e ", " depois ", "digite", "escreva", "pesquise", "toque", "clique").none { it in lower }) {
            val pkg = findLaunchablePackage(context, onlyApp) ?: return null
            openPackage(context, pkg)
            return Result("$onlyApp aberto.", true)
        }

        if (service == null) return null

        val typePrefix = listOf("digite ", "escreva ").firstOrNull { lower.startsWith(it) }
        if (typePrefix != null) {
            var text = original.substring(typePrefix.length).trim()
            val enterTail = Regex("(?i)\\s+(e\\s+)?(dá|da|de|aperte|pressione)\\s+enter\\s*$")
            val wantsEnter = enterTail.containsMatchIn(text)
            if (wantsEnter) text = text.replace(enterTail, "").trim()
            if (text.isNotBlank() && service.setFocusedText(text)) {
                if (wantsEnter) robustEnter(service)
                return Result(if (wantsEnter) "Texto digitado e Enter enviado." else "Texto digitado.", true)
            }
        }

        val directEnter = Regex("\\b(dá|da|de|aperte|pressione|manda|envia)?\\s*enter\\b").containsMatchIn(lower) &&
            !containsOpenVerb(lower) && extractRequestedApp(lower) == null && lower.length < 48
        if (directEnter) {
            status("Device Agent: Enter…")
            return if (robustEnter(service)) Result("Enter enviado.", true) else Result("Não consegui enviar Enter nesta tela.", false)
        }
        if (lower in setOf("volta", "voltar", "volte", "back")) return Result(if (service.back()) "Voltei." else "Não consegui voltar.", true)
        if (lower in setOf("home", "tela inicial", "vai pra home", "vá pra home")) return Result(if (service.home()) "Tela inicial aberta." else "Não consegui abrir a tela inicial.", true)
        if ("notifica" in lower && lower.length < 40) return Result(if (service.notifications()) "Notificações abertas." else "Não consegui abrir as notificações.", true)
        if ("recentes" in lower && lower.length < 40) return Result(if (service.recents()) "Apps recentes abertos." else "Não consegui abrir os apps recentes.", true)
        return null
    }

    private suspend fun runScreenDrivenLoop(
        context: Context,
        apiKey: String,
        command: String,
        status: (String) -> Unit
    ): Result {
        val service = StudioAccessibilityService.instance ?: return Result("Device Agent de Acessibilidade não está ativo.", false)
        var acted = false
        var lastNote = ""

        repeat(10) { round ->
            if (cancelled()) return Result("Tarefa interrompida por você.", acted)
            val snapshot = service.snapshot(190)
            status("Device Agent: planejando • etapa ${round + 1}…")
            val plan = planDeviceBatch(apiKey, command, snapshot, round)
            val actions = extractActions(plan)
            if (actions.isEmpty()) return Result(plan.optString("message").ifBlank { "Não encontrei uma próxima ação segura." }, acted)

            for (actionObj in actions.take(5)) {
                if (cancelled()) return Result("Tarefa interrompida por você.", acted)
                val action = actionObj.optString("action", "finish")
                val target = actionObj.optString("target")
                val text = actionObj.optString("text")
                lastNote = actionObj.optString("reason", lastNote)
                val before = service.eventSerial()

                when (action) {
                    "open_app" -> {
                        val appName = actionObj.optString("app", target)
                        val pkg = findLaunchablePackage(context, appName)
                            ?: return Result("Não encontrei o app '$appName' para abrir.", acted)
                        status("Abrindo $appName…")
                        openPackage(context, pkg)
                        acted = true
                        waitForUiChange(service, before, 520)
                    }
                    "click_text" -> {
                        status("Tocando em $target…")
                        if (target.isBlank() || !service.clickText(target)) break
                        acted = true
                        waitForUiChange(service, before, 420)
                    }
                    "long_click_text" -> {
                        if (target.isBlank() || !service.longClickText(target)) break
                        acted = true
                        waitForUiChange(service, before, 450)
                    }
                    "set_text", "type_text" -> {
                        if (!service.setFocusedText(text)) break
                        acted = true
                        delay(90)
                    }
                    "paste" -> {
                        val clipboard = context.getSystemService(ClipboardManager::class.java)
                        clipboard.setPrimaryClip(ClipData.newPlainText("xKiro", text))
                        val pasted = if (ShizukuBridge.hasPermission()) ShizukuBridge.paste().isSuccess else service.setFocusedText(text)
                        if (!pasted) break
                        acted = true
                        delay(100)
                    }
                    "enter" -> {
                        status("Confirmando…")
                        if (!robustEnter(service)) break
                        acted = true
                        waitForUiChange(service, before, 450)
                    }
                    "back" -> { service.back(); acted = true; waitForUiChange(service, before, 350) }
                    "home" -> { service.home(); acted = true; waitForUiChange(service, before, 350) }
                    "recents" -> { service.recents(); acted = true; waitForUiChange(service, before, 350) }
                    "notifications" -> { service.notifications(); acted = true; waitForUiChange(service, before, 350) }
                    "scroll", "scroll_down" -> {
                        if (!service.scrollForward()) break
                        acted = true
                        waitForUiChange(service, before, 320)
                    }
                    "scroll_up" -> {
                        if (!service.scrollBackward()) break
                        acted = true
                        waitForUiChange(service, before, 320)
                    }
                    "tap" -> {
                        val x = actionObj.optDouble("x", -1.0).toFloat()
                        val y = actionObj.optDouble("y", -1.0).toFloat()
                        if (x < 0 || y < 0 || !service.tap(x, y)) break
                        acted = true
                        waitForUiChange(service, before, 350)
                    }
                    "swipe" -> {
                        val ok = service.swipe(
                            actionObj.optDouble("x1", 0.5).toFloat(), actionObj.optDouble("y1", 0.8).toFloat(),
                            actionObj.optDouble("x2", 0.5).toFloat(), actionObj.optDouble("y2", 0.2).toFloat(),
                            actionObj.optLong("duration", 220L)
                        )
                        if (!ok) break
                        acted = true
                        waitForUiChange(service, before, 350)
                    }
                    "wait" -> delay(actionObj.optLong("ms", 300L).coerceIn(80L, 1600L))
                    "finish" -> return Result(actionObj.optString("message").ifBlank { lastNote.ifBlank { "Comando concluído." } }, acted)
                    "need_confirmation" -> return Result(actionObj.optString("message").ifBlank { "Preciso da sua confirmação para a próxima ação sensível." }, acted)
                    else -> break
                }
            }
        }
        return Result(lastNote.ifBlank { "Parei após várias etapas para evitar um loop. Você pode mandar continuar." }, acted)
    }

    private fun extractActions(plan: JSONObject): List<JSONObject> {
        val arr = plan.optJSONArray("actions")
        if (arr != null) return buildList {
            for (i in 0 until arr.length()) arr.optJSONObject(i)?.let(::add)
        }
        return if (plan.has("action")) listOf(plan) else emptyList()
    }

    private suspend fun robustEnter(service: StudioAccessibilityService): Boolean {
        if (ShizukuBridge.hasPermission()) {
            if (ShizukuBridge.enter().isSuccess) return true
        }
        if (service.clickAny("Enviar", "Send", "Ir", "Go", "Pesquisar", "Search", "OK", "Concluído", "Concluido", "Done")) return true
        return false
    }

    private suspend fun waitForUiChange(service: StudioAccessibilityService, before: Long, timeoutMs: Long) {
        val start = System.currentTimeMillis()
        while (!cancelled() && System.currentTimeMillis() - start < timeoutMs) {
            if (service.eventSerial() != before) return
            delay(25)
        }
    }

    private suspend fun executeTermux(context: Context, apiKey: String, request: String, status: (String) -> Unit): Result {
        if (cancelled()) return Result("Tarefa interrompida por você.", false)
        if (!ShizukuBridge.binderAlive) return Result("Shizuku não está conectado.", false)
        if (!ShizukuBridge.hasPermission()) {
            ShizukuBridge.requestPermission()
            return Result("Autorize o xKiro AI Studio no Shizuku e envie o comando novamente.", false)
        }
        val service = StudioAccessibilityService.instance
            ?: return Result("Ative o Device Agent em Acessibilidade antes de controlar o Termux.", false)

        status("Gerando o código…")
        val python = buildPythonForRequestFast(apiKey, request)
        if (cancelled()) return Result("Tarefa interrompida por você.", false)
        val encoded = Base64.getEncoder().encodeToString(python.toByteArray(Charsets.UTF_8))
        val fileName = "xkiro_simple_ai.py"
        val terminalCommand = "echo $encoded | base64 -d > ~/$fileName && python ~/$fileName"

        status("Abrindo Termux…")
        val before = service.eventSerial()
        openPackage(context, "com.termux")
        waitForUiChange(service, before, 600)
        if (cancelled()) return Result("Tarefa interrompida por você.", true)

        val clipboard = context.getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("xKiro command", terminalCommand))

        status("Executando no Termux…")
        val pasteOk = ShizukuBridge.paste().isSuccess
        if (!pasteOk) return Result("Termux abriu, mas não consegui colar o comando.", true)
        delay(90)
        if (!robustEnter(service)) return Result("O comando foi colado, mas o Enter não foi aceito.", true)

        delay(450)
        val snapshot = service.snapshot(90)
        return Result(
            "Termux recebeu e executou ~/xkiro_simple_ai.py. " +
                if (snapshot.contains("Traceback", true) || snapshot.contains("Error", true))
                    "Detectei sinal de erro na tela; mande 'corrija o erro do Termux' para eu continuar."
                else "Execução enviada com sucesso.",
            true
        )
    }

    private suspend fun buildPythonForRequestFast(apiKey: String, request: String): String = withContext(Dispatchers.IO) {
        val model = getFastModelId(apiKey)
        val raw = XKiroClient.chat(
            apiKey,
            model,
            "Você é um programador Python para Termux. Retorne SOMENTE código Python válido, sem markdown, sem crases. Prefira biblioteca padrão e um arquivo pequeno executável.",
            "Pedido: $request",
            1800,
            0.05
        )
        cleanCode(raw).ifBlank {
            "print('xKiro AI simples pronta. Digite sair para encerrar.')\n" +
            "while True:\n" +
            "    msg = input('Você: ').strip().lower()\n" +
            "    if msg in {'sair','exit','quit'}: break\n" +
            "    print('IA:', 'Olá! Como posso ajudar?' if 'oi' in msg else 'Você disse: ' + msg)\n"
        }
    }

    private fun cleanCode(raw: String): String {
        var s = raw.trim()
        if (s.startsWith("```")) s = s.substringAfter('\n').substringBeforeLast("```").trim()
        return s
    }

    private suspend fun getFastModelId(apiKey: String): String {
        val now = System.currentTimeMillis()
        val hash = apiKey.hashCode()
        val cached = cachedPlannerModel
        if (cached != null && cachedPlannerKeyHash == hash && cachedPlannerUntil > now) return cached

        val models = AgentOrchestrator.accessReport(apiKey, 7).verifiedUsable
        require(models.isNotEmpty()) { "Nenhum modelo xKiro utilizável agora." }
        val speedTokens = listOf("flash", "nano", "mini", "fast", "turbo", "haiku", "lite")
        val chosen = models.firstOrNull { m -> speedTokens.any { it in m.id.lowercase() } } ?: models.first()
        cachedPlannerModel = chosen.id
        cachedPlannerKeyHash = hash
        cachedPlannerUntil = now + 10 * 60 * 1000L
        return chosen.id
    }

    private suspend fun planDeviceBatch(apiKey: String, request: String, snapshot: String, step: Int): JSONObject = withContext(Dispatchers.IO) {
        val modelId = getFastModelId(apiKey)
        val raw = XKiroClient.chat(
            apiKey,
            modelId,
            """
                Você controla o Android do próprio usuário. Retorne SOMENTE JSON, sem markdown.
                Planeje de 1 a 5 ações imediatas em {"actions":[...]} para avançar o pedido rapidamente.
                Ações: open_app, click_text, long_click_text, set_text, type_text, paste, enter, back, home, recents, notifications, scroll_down, scroll_up, tap, swipe, wait, finish, need_confirmation.
                Campos: action, app, target, text, ms, message, reason, x, y, x1, y1, x2, y2, duration.
                Prefira texto/Accessibility em vez de coordenadas. Só use coordenadas se a árvore não oferecer alvo textual.
                Você pode navegar, abrir apps, preencher campos, confirmar Enter, voltar, rolar e operar ferramentas livremente quando isso for reversível e fizer parte do pedido.
                Para compra/pagamento, exclusão destrutiva, instalação de software ou mudança de senha/conta/permissão, use need_confirmation imediatamente antes dessa ação. Para envio de mensagem/arquivo, a própria frase original do usuário conta como confirmação se ela pediu explicitamente o destinatário e o envio; caso contrário use need_confirmation.
                Não invente sucesso. Se a tarefa acabou, finish.
            """.trimIndent(),
            "PEDIDO: $request\nETAPA: $step\nTELA:\n${snapshot.take(12000)}",
            520,
            0.0
        )
        parseJsonObject(raw)
    }

    private fun parseJsonObject(raw: String): JSONObject {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return JSONObject().put("actions", JSONArray().put(JSONObject().put("action", "finish").put("message", raw.take(300))))
        return runCatching { JSONObject(raw.substring(start, end + 1)) }
            .getOrElse { JSONObject().put("actions", JSONArray().put(JSONObject().put("action", "finish").put("message", "Não consegui interpretar o plano."))) }
    }

    private fun containsOpenVerb(text: String): Boolean =
        listOf("abra ", "abre ", "abrir ", "entre no", "entra no", "vá para", "vai para").any { it in text }

    private fun extractRequestedApp(text: String): String? {
        val aliases = listOf("termux", "whatsapp", "youtube", "chrome", "configurações", "configuracoes")
        return aliases.firstOrNull { it in text }
    }

    private fun findLaunchablePackage(context: Context, appName: String): String? {
        val normalized = appName.lowercase(Locale.ROOT).trim()
        val known = when {
            "termux" in normalized -> "com.termux"
            "whatsapp" in normalized -> "com.whatsapp"
            "youtube" in normalized -> "com.google.android.youtube"
            "chrome" in normalized -> "com.android.chrome"
            "configura" in normalized -> "com.android.settings"
            else -> null
        }
        if (known != null && context.packageManager.getLaunchIntentForPackage(known) != null) return known

        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val candidates = context.packageManager.queryIntentActivities(launcher, 0)
        return candidates.firstOrNull { info ->
            val label = info.loadLabel(context.packageManager)?.toString()?.lowercase(Locale.ROOT).orEmpty()
            label == normalized || label.contains(normalized) || normalized.contains(label)
        }?.activityInfo?.packageName
    }

    private fun openPackage(context: Context, packageName: String) {
        val pm = context.packageManager
        val launch = pm.getLaunchIntentForPackage(packageName)
            ?: Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                setPackage(packageName)
            }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
    }
}
