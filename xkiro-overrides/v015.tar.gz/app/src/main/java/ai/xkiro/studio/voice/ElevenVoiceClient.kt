package ai.xkiro.studio.voice

import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object ElevenVoiceClient {
    private fun synthesizeWithModel(apiKey: String, voiceId: String, text: String, dest: File, modelId: String): File {
        require(apiKey.isNotBlank() && voiceId.isNotBlank())
        val url = URL("https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_44100_128")
        val c = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12_000
            readTimeout = 45_000
            doOutput = true
            setRequestProperty("xi-api-key", apiKey)
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Connection", "keep-alive")
        }
        val payload = JSONObject()
            .put("text", text.take(3200))
            .put("model_id", modelId)
        c.outputStream.use { it.write(payload.toString().toByteArray()) }
        if (c.responseCode !in 200..299) {
            val err = c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            error("Voice API HTTP ${c.responseCode}: ${err.take(300)}")
        }
        c.inputStream.use { input -> dest.outputStream().use { input.copyTo(it) } }
        return dest
    }

    fun synthesize(apiKey: String, voiceId: String, text: String, dest: File): File {
        return runCatching {
            synthesizeWithModel(apiKey, voiceId, text, dest, "eleven_flash_v2_5")
        }.getOrElse {
            synthesizeWithModel(apiKey, voiceId, text, dest, "eleven_multilingual_v2")
        }
    }
}
