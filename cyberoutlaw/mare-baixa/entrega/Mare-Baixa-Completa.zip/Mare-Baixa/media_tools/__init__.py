"""Mídia do menu CyberOutlaw."""
