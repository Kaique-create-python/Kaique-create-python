#include <stdlib.h>
#include <string.h>
#include <libpad.h>
#include "menu.h"

static const char *s_items[MENU_ITEM_COUNT] = {
    "NOVO JOGO",
    "CONTINUAR",
    "NOITES",
    "EXTRAS",
    "OPCOES",
    "CREDITOS"
};

static const SceneId s_targets[MENU_ITEM_COUNT] = {
    SCENE_NEW_GAME,
    SCENE_CONTINUE,
    SCENE_NIGHTS,
    SCENE_EXTRAS,
    SCENE_OPTIONS,
    SCENE_CREDITS
};

static u32 rng_next(u32 *s)
{
    u32 x = *s;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    *s = x ? x : 0xA341316Cu;
    return *s;
}

static int range_rand(u32 *rng, int minv, int maxv)
{
    u32 r = rng_next(rng);
    return minv + (int)(r % (u32)(maxv - minv + 1));
}

void menu_init(MenuState *menu)
{
    memset(menu, 0, sizeof(*menu));
    menu->selected = 0;
    menu->bg_state = 0;
    menu->bg_next_change = 480;
    menu->transition_target = SCENE_MENU;
    menu->rng = 0x4D435032u;
}

void menu_update(MenuState *menu, AppState *app, const InputState *input, AudioSystem *audio)
{
    int any_input = input->pressed != 0;

    if (menu->transition_timer > 0) {
        menu->transition_timer--;
        if (menu->transition_timer == 0) {
            app->scene = menu->transition_target;
        }
        return;
    }

    if (any_input) {
        menu->idle_frames = 0;
        menu->idle_event = 0;
        menu->idle_timer = 0;
    } else {
        menu->idle_frames++;
    }

    if (input->pressed & PAD_UP) {
        menu->selected = (menu->selected + MENU_ITEM_COUNT - 1) % MENU_ITEM_COUNT;
        menu->menu_jitter = 4.0f;
        audio_nav(audio);
    }
    if (input->pressed & PAD_DOWN) {
        menu->selected = (menu->selected + 1) % MENU_ITEM_COUNT;
        menu->menu_jitter = 4.0f;
        audio_nav(audio);
    }

    if (input->pressed & PAD_CROSS) {
        menu->transition_target = s_targets[menu->selected];
        menu->transition_timer = 22;
        audio_confirm(audio);
        audio_glitch(audio);
    }

    if (menu->menu_jitter > 0.0f) menu->menu_jitter *= 0.68f;

    menu->bg_timer++;
    if (menu->bg_timer >= menu->bg_next_change && menu->idle_event == 0) {
        int next = range_rand(&menu->rng, 0, MENU_BG_COUNT - 1);
        if (next == menu->bg_state) next = (next + 1) % MENU_BG_COUNT;
        menu->bg_state = next;
        menu->bg_timer = 0;
        menu->bg_next_change = range_rand(&menu->rng, 420, 780);
    }

    if (menu->idle_frames > range_rand(&menu->rng, 1200, 1800) && menu->idle_event == 0) {
        menu->idle_event = 1 + (int)(rng_next(&menu->rng) % 3u);
        menu->idle_timer = range_rand(&menu->rng, 180, 360);
        menu->bg_state = 4;
        audio_glitch(audio);
    }

    if (menu->idle_event) {
        if (--menu->idle_timer <= 0) {
            menu->idle_event = 0;
            menu->idle_frames = 0;
            menu->bg_state = range_rand(&menu->rng, 0, 2);
        }
    }
}

void menu_render(MenuState *menu, Renderer *renderer, Assets *assets, ScreenEffects *fx)
{
    int i;
    float base_x = 55.0f;
    float base_y = 158.0f;
    float zoom = 1.0f + ((renderer->frame % 900) / 900.0f) * 0.035f;
    float pan_x = (float)((renderer->frame / 6) % 18) - 9.0f;
    float intensity = 0.0f;
    GSTEXTURE *bg;

    if (menu->idle_event) intensity = 0.70f;
    if (menu->transition_timer > 0) intensity = 1.0f - (menu->transition_timer / 22.0f) * 0.35f;

    bg = assets_get_menu_bg(assets, menu->bg_state);
    if (bg) {
        renderer_draw_texture(renderer, bg, zoom, pan_x * 0.20f, 0.0f,
                              GS_SETREG_RGBAQ(0x80, 0x80, 0x80, 0x80, 0));
    } else {
        renderer_rect(renderer, 0, 0, renderer->gs->Width, renderer->gs->Height, 1,
                      GS_SETREG_RGBAQ(10, 7, 8, 0x80, 0));
    }

    /* Readability panel. */
    renderer_rect(renderer, 25, 86, 322, 405, 3, GS_SETREG_RGBAQ(0, 0, 0, 72, 0));
    renderer_rect(renderer, 25, 86, 30, 405, 4, GS_SETREG_RGBAQ(135, 22, 18, 62, 0));

    renderer_text(renderer, 50, 103, 6, 0.72f, GS_SETREG_RGBAQ(180, 170, 160, 0x80, 0), "MIDNIGHT CIRCUIT");
    renderer_text(renderer, 50, 126, 6, 0.48f, GS_SETREG_RGBAQ(128, 45, 39, 0x80, 0), "PIZZA");

    for (i = 0; i < MENU_ITEM_COUNT; ++i) {
        float y = base_y + i * 34.0f;
        if (i == menu->selected) {
            float j = menu->menu_jitter;
            renderer_rect(renderer, 42 - j, y - 5, 285 + j, y + 24, 5,
                          GS_SETREG_RGBAQ(72, 8, 6, 55, 0));
            renderer_rect(renderer, 42 - j, y + 24, 285 + j, y + 25, 6,
                          GS_SETREG_RGBAQ(148, 36, 28, 90, 0));
            renderer_text(renderer, base_x + j * 0.45f, y, 7, 0.52f,
                          GS_SETREG_RGBAQ(210, 190, 176, 0x80, 0), s_items[i]);
        } else {
            renderer_text(renderer, base_x, y, 7, 0.50f,
                          GS_SETREG_RGBAQ(105, 102, 98, 0x80, 0), s_items[i]);
        }
    }

    renderer_text(renderer, 44, 386, 7, 0.31f,
                  GS_SETREG_RGBAQ(92, 92, 92, 0x80, 0), "D-PAD: MOVER   X: CONFIRMAR");

    effects_update(fx, renderer->frame, intensity);
    effects_render(fx, renderer);

    if (menu->transition_timer > 0) {
        int t = 22 - menu->transition_timer;
        renderer_rect(renderer, 0, 0, renderer->gs->Width, renderer->gs->Height, 25,
                      GS_SETREG_RGBAQ(0, 0, 0, (u8)(t * 5), 0));
    }
}
