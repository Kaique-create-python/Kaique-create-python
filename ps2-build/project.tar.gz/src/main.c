#include <stdio.h>
#include <string.h>
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include "app.h"
#include "input.h"
#include "renderer.h"
#include "assets.h"
#include "effects.h"
#include "audio.h"
#include "menu.h"
#include "scenes.h"

static int is_disc_boot(int argc, char **argv)
{
    if (argc > 0 && argv && argv[0]) {
        if (strstr(argv[0], "cdrom0:") || strstr(argv[0], "cdfs:")) return 1;
    }
    return 0;
}

int main(int argc, char *argv[])
{
    Renderer renderer;
    Assets assets;
    ScreenEffects fx;
    AudioSystem audio;
    MenuState menu;
    InputState input;
    AppState app;
    int pad_ret;

    memset(&app, 0, sizeof(app));
    app.scene = SCENE_BOOT;
    app.next_scene = SCENE_MENU;
    app.running = 1;
    app.disc_mode = is_disc_boot(argc, argv);

    SifInitRpc(0);

    if (renderer_init(&renderer) < 0) {
        return 1;
    }

    pad_ret = input_init();
    if (pad_ret < 0) {
        printf("PAD init failed: %d\n", pad_ret);
    }

    assets_init(&assets, renderer.gs, app.disc_mode);
    effects_init(&fx);
    audio_init(&audio, app.disc_mode);
    menu_init(&menu);

    while (app.running) {
        input_update(&input);
        scenes_update(&app, &menu, &input, &audio);

        renderer_begin(&renderer, GS_SETREG_RGBAQ(0, 0, 0, 0x80, 0));
        scenes_render(&app, &menu, &renderer, &assets, &fx);
        renderer_end(&renderer);
    }

    audio_shutdown(&audio);
    assets_shutdown(&assets, renderer.gs);
    input_shutdown();
    renderer_shutdown(&renderer);
    SifExitRpc();
    return 0;
}
