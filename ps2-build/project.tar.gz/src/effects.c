#include <math.h>
#include "effects.h"

static u32 rng_next(u32 *s)
{
    u32 x = *s;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    *s = x ? x : 0x13579BDFu;
    return *s;
}

static u8 clamp_alpha(float a)
{
    if (a < 0.0f) a = 0.0f;
    if (a > 127.0f) a = 127.0f;
    return (u8)a;
}

void effects_init(ScreenEffects *fx)
{
    fx->scanlines = 0.35f;
    fx->grain = 0.25f;
    fx->flicker = 0.10f;
    fx->glitch = 0.0f;
    fx->vignette = 0.55f;
    fx->darken = 0.0f;
    fx->rng = 0xC1AC017u;
}

void effects_update(ScreenEffects *fx, int frame, float intensity)
{
    float pulse = (float)((frame % 120) < 3) * 0.15f;
    fx->flicker = 0.06f + pulse + intensity * 0.20f;
    fx->grain = 0.18f + intensity * 0.28f;
    fx->glitch = intensity;
    fx->darken = intensity * 0.22f;
}

void effects_render(ScreenEffects *fx, Renderer *renderer)
{
    int y, i;
    float w = (float)renderer->gs->Width;
    float h = (float)renderer->gs->Height;
    u8 a;

    /* CRT scanlines. */
    a = clamp_alpha(11.0f + 28.0f * fx->scanlines);
    for (y = 1; y < (int)h; y += 6) {
        renderer_rect(renderer, 0, (float)y, w, (float)y + 1.0f, 10,
                      GS_SETREG_RGBAQ(0, 0, 0, a, 0));
    }

    /* Analog grain: sparse tiny horizontal noise fragments. */
    for (i = 0; i < (int)(8 + fx->grain * 26); ++i) {
        u32 r = rng_next(&fx->rng);
        float yy = (float)(r % (u32)h);
        float xx = (float)((r >> 9) % (u32)w);
        float ww = 3.0f + (float)((r >> 18) % 28);
        u8 c = (u8)(70 + ((r >> 24) & 0x3F));
        renderer_rect(renderer, xx, yy, xx + ww, yy + 1.0f, 11,
                      GS_SETREG_RGBAQ(c, c, c, clamp_alpha(7.0f + fx->grain * 18.0f), 0));
    }

    /* VHS glitch bands. */
    if (fx->glitch > 0.05f) {
        int bands = 1 + (int)(fx->glitch * 5.0f);
        for (i = 0; i < bands; ++i) {
            u32 r = rng_next(&fx->rng);
            float yy = (float)(r % (u32)h);
            float bh = 2.0f + (float)((r >> 12) % 9);
            renderer_rect(renderer, 0, yy, w, yy + bh, 12,
                          GS_SETREG_RGBAQ(115, 16, 16, clamp_alpha(10 + fx->glitch * 35), 0));
            if ((r & 3) == 0) {
                renderer_rect(renderer, 0, yy + bh, w, yy + bh + 1, 13,
                              GS_SETREG_RGBAQ(140, 140, 140, 24, 0));
            }
        }
    }

    /* Cheap vignette: four alpha-faded edge blocks. */
    a = clamp_alpha(30.0f + 45.0f * fx->vignette);
    renderer_rect(renderer, 0, 0, 58, h, 14, GS_SETREG_RGBAQ(0, 0, 0, a, 0));
    renderer_rect(renderer, w - 58, 0, w, h, 14, GS_SETREG_RGBAQ(0, 0, 0, a, 0));
    renderer_rect(renderer, 0, 0, w, 34, 14, GS_SETREG_RGBAQ(0, 0, 0, a, 0));
    renderer_rect(renderer, 0, h - 34, w, h, 14, GS_SETREG_RGBAQ(0, 0, 0, a, 0));

    if (fx->darken > 0.001f) {
        renderer_rect(renderer, 0, 0, w, h, 15,
                      GS_SETREG_RGBAQ(0, 0, 0, clamp_alpha(fx->darken * 95.0f), 0));
    }

    /* Rare one-frame CRT flicker. */
    if ((rng_next(&fx->rng) & 0xFFu) < (u32)(fx->flicker * 14.0f)) {
        renderer_rect(renderer, 0, 0, w, h, 16,
                      GS_SETREG_RGBAQ(115, 115, 115, 13, 0));
    }
}
