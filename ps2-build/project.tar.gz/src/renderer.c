#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dmaKit.h>
#include <gsKit.h>
#include <gsToolkit.h>
#include "renderer.h"

int renderer_init(Renderer *renderer)
{
    memset(renderer, 0, sizeof(*renderer));

    renderer->gs = gsKit_init_global();
    if (!renderer->gs) return -1;

    renderer->gs->ZBuffering = GS_SETTING_OFF;
    renderer->gs->DoubleBuffering = GS_SETTING_ON;
    renderer->gs->Dithering = GS_SETTING_ON;
    renderer->gs->PSM = GS_PSM_CT16S;
    renderer->gs->PrimAlphaEnable = GS_SETTING_ON;

    dmaKit_init(D_CTRL_RELE_OFF, D_CTRL_MFD_OFF, D_CTRL_STS_UNSPEC,
                D_CTRL_STD_OFF, D_CTRL_RCYC_8, 1 << DMA_CHANNEL_GIF);
    dmaKit_chan_init(DMA_CHANNEL_GIF);

    gsKit_init_screen(renderer->gs);
    gsKit_mode_switch(renderer->gs, GS_ONESHOT);
    gsKit_set_primalpha(renderer->gs, GS_SETREG_ALPHA(0, 1, 0, 1, 0), 0);
    gsKit_TexManager_init(renderer->gs);

    renderer->font = gsKit_init_fontm();
    if (renderer->font && gsKit_fontm_upload(renderer->gs, renderer->font) >= 0) {
        renderer->font->Spacing = 0.90f;
        renderer->font_ok = 1;
    } else {
        renderer->font_ok = 0;
    }

    return 0;
}

void renderer_begin(Renderer *renderer, u64 clear_color)
{
    gsKit_clear(renderer->gs, clear_color);
}

void renderer_end(Renderer *renderer)
{
    gsKit_queue_exec(renderer->gs);
    gsKit_sync_flip(renderer->gs);
    gsKit_TexManager_nextFrame(renderer->gs);
    renderer->frame++;
}

void renderer_draw_texture(Renderer *renderer, GSTEXTURE *tex, float zoom, float pan_x, float pan_y, u64 tint)
{
    float sw, sh, crop_w, crop_h, u1, v1, u2, v2;

    if (!tex || !tex->Mem) return;
    gsKit_TexManager_bind(renderer->gs, tex);

    sw = (float)renderer->gs->Width;
    sh = (float)renderer->gs->Height;
    if (zoom < 1.0f) zoom = 1.0f;

    crop_w = (float)tex->Width / zoom;
    crop_h = (float)tex->Height / zoom;
    u1 = ((float)tex->Width - crop_w) * 0.5f + pan_x;
    v1 = ((float)tex->Height - crop_h) * 0.5f + pan_y;
    u2 = u1 + crop_w;
    v2 = v1 + crop_h;

    if (u1 < 0) { u2 -= u1; u1 = 0; }
    if (v1 < 0) { v2 -= v1; v1 = 0; }
    if (u2 > tex->Width) { u1 -= (u2 - tex->Width); u2 = tex->Width; }
    if (v2 > tex->Height) { v1 -= (v2 - tex->Height); v2 = tex->Height; }

    gsKit_prim_sprite_texture(renderer->gs, tex,
        0.0f, 0.0f, u1, v1,
        sw, sh, u2, v2,
        1, tint);
}

void renderer_rect(Renderer *renderer, float x1, float y1, float x2, float y2, int z, u64 color)
{
    gsKit_prim_sprite(renderer->gs, x1, y1, x2, y2, z, color);
}

void renderer_text(Renderer *renderer, float x, float y, int z, float scale, u64 color, const char *text)
{
    if (renderer->font_ok) {
        gsKit_fontm_print_scaled(renderer->gs, renderer->font, x, y, z, scale, color, text);
    }
}

void renderer_shutdown(Renderer *renderer)
{
    if (renderer->font) gsKit_free_fontm(renderer->gs, renderer->font);
    if (renderer->gs) gsKit_deinit_global(renderer->gs);
    memset(renderer, 0, sizeof(*renderer));
}
