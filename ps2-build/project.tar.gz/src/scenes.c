#include <libpad.h>
#include "scenes.h"

static void render_secondary(AppState *app, Renderer *r, const char *title, const char *subtitle, ScreenEffects *fx)
{
    renderer_rect(r, 0, 0, r->gs->Width, r->gs->Height, 1, GS_SETREG_RGBAQ(4, 4, 5, 0x80, 0));
    renderer_rect(r, 0, 0, r->gs->Width, 70, 2, GS_SETREG_RGBAQ(15, 4, 5, 0x80, 0));
    renderer_text(r, 42, 96, 4, 0.78f, GS_SETREG_RGBAQ(190, 180, 170, 0x80, 0), title);
    renderer_text(r, 44, 150, 4, 0.43f, GS_SETREG_RGBAQ(110, 104, 101, 0x80, 0), subtitle);
    renderer_text(r, 44, 385, 4, 0.34f, GS_SETREG_RGBAQ(95, 95, 95, 0x80, 0), "O: VOLTAR");
    effects_update(fx, app->frame, 0.12f);
    effects_render(fx, r);
}

void scenes_update(AppState *app, MenuState *menu, const InputState *input, AudioSystem *audio)
{
    app->frame++;

    if (app->scene == SCENE_BOOT) {
        if (app->frame > 245 || (input->pressed & PAD_START) || (input->pressed & PAD_CROSS)) {
            app->scene = SCENE_MENU;
            app->frame = 0;
            menu_init(menu);
        }
        return;
    }

    if (app->scene == SCENE_MENU) {
        menu_update(menu, app, input, audio);
        return;
    }

    if (input->pressed & PAD_CIRCLE) {
        app->scene = SCENE_MENU;
        app->frame = 0;
        menu_init(menu);
        audio_nav(audio);
    }
}

void scenes_render(AppState *app, MenuState *menu, Renderer *renderer, Assets *assets, ScreenEffects *fx)
{
    if (app->scene == SCENE_BOOT) {
        float a;
        if (assets->boot_ok) {
            renderer_draw_texture(renderer, &assets->boot, 1.02f, 0, 0,
                                  GS_SETREG_RGBAQ(0x80, 0x80, 0x80, 0x80, 0));
        }
        renderer_rect(renderer, 0, 0, renderer->gs->Width, renderer->gs->Height, 3,
                      GS_SETREG_RGBAQ(0, 0, 0, 35, 0));

        if (app->frame < 65) a = app->frame / 65.0f;
        else if (app->frame > 190) a = (245 - app->frame) / 55.0f;
        else a = 1.0f;
        if (a < 0) a = 0;
        if (a > 1) a = 1;

        renderer_text(renderer, 96, 180, 6, 0.86f,
                      GS_SETREG_RGBAQ(180, 171, 160, (u8)(a * 0x80), 0), "MIDNIGHT CIRCUIT");
        renderer_text(renderer, 246, 220, 6, 0.52f,
                      GS_SETREG_RGBAQ(145, 40, 34, (u8)(a * 0x80), 0), "PIZZA");
        effects_update(fx, app->frame, ((app->frame % 73) < 5) ? 0.55f : 0.12f);
        effects_render(fx, renderer);
        return;
    }

    switch (app->scene) {
        case SCENE_MENU:
            menu_render(menu, renderer, assets, fx);
            break;
        case SCENE_NEW_GAME:
            render_secondary(app, renderer, "NOVO JOGO", "NOITE 1  //  SISTEMA DE GAMEPLAY SERA A PROXIMA ETAPA", fx);
            break;
        case SCENE_CONTINUE:
            render_secondary(app, renderer, "CONTINUAR", "SAVE NO MEMORY CARD SERA CONECTADO AQUI", fx);
            break;
        case SCENE_NIGHTS:
            render_secondary(app, renderer, "NOITES", "SELECAO DE NOITES E DESBLOQUEIOS", fx);
            break;
        case SCENE_EXTRAS:
            render_secondary(app, renderer, "EXTRAS", "GALERIA DOS ANIMATRONICOS E CONTEUDO DESBLOQUEAVEL", fx);
            break;
        case SCENE_OPTIONS:
            render_secondary(app, renderer, "OPCOES", "BRILHO  EFEITOS CRT  AUDIO  VIBRACAO", fx);
            break;
        case SCENE_CREDITS:
            render_secondary(app, renderer, "CREDITOS", "MIDNIGHT CIRCUIT PIZZA  //  PROJETO HOMEBREW PS2", fx);
            break;
        default:
            break;
    }
}
