#include <string.h>
#include <tamtypes.h>
#include <loadfile.h>
#include <audsrv.h>
#include "audio.h"

#define NAV_SAMPLES 1920
#define CONFIRM_SAMPLES 3600
#define GLITCH_SAMPLES 4800

static s16 s_nav[NAV_SAMPLES];
static s16 s_confirm[CONFIRM_SAMPLES];
static s16 s_glitch[GLITCH_SAMPLES];
static int s_generated = 0;

static void generate_sounds(void)
{
    u32 noise = 0x91E10DA5u;
    int i;
    if (s_generated) return;

    for (i = 0; i < NAV_SAMPLES; ++i) {
        int env = NAV_SAMPLES - i;
        int sq = ((i / 15) & 1) ? 1 : -1;
        s_nav[i] = (s16)(sq * (env * 7));
    }

    for (i = 0; i < CONFIRM_SAMPLES; ++i) {
        int env = CONFIRM_SAMPLES - i;
        int p1 = ((i / 19) & 1) ? 1 : -1;
        int p2 = ((i / 31) & 1) ? 1 : -1;
        int v = (p1 * 5 + p2 * 3) * env;
        s_confirm[i] = (s16)(v > 26000 ? 26000 : (v < -26000 ? -26000 : v));
    }

    for (i = 0; i < GLITCH_SAMPLES; ++i) {
        int env = GLITCH_SAMPLES - i;
        noise ^= noise << 13;
        noise ^= noise >> 17;
        noise ^= noise << 5;
        s_glitch[i] = (s16)(((int)(noise & 0xFFFF) - 32768) * env / GLITCH_SAMPLES / 3);
    }
    s_generated = 1;
}

static void play(AudioSystem *audio, const s16 *samples, int count)
{
    int bytes;
    if (!audio->enabled) return;
    bytes = count * (int)sizeof(s16);
    if (bytes > audsrv_available()) return;
    audsrv_play_audio((const char *)samples, bytes);
}

void audio_init(AudioSystem *audio, int disc_mode)
{
    int ret;
    audsrv_fmt_t format;
    memset(audio, 0, sizeof(*audio));
    audio->disc_mode = disc_mode;
    generate_sounds();

    SifLoadModule("rom0:LIBSD", 0, NULL);
    ret = SifLoadModule(disc_mode ? "cdrom0:\\IRX\\AUDSRV.IRX;1" : "host:iso/IRX/AUDSRV.IRX", 0, NULL);
    if (ret < 0) {
        audio->enabled = 0;
        return;
    }

    if (audsrv_init() < 0) return;
    format.freq = 48000;
    format.bits = 16;
    format.channels = 1;
    if (audsrv_set_format(&format) < 0) return;
    audsrv_set_volume(MAX_VOLUME / 2);
    audio->enabled = 1;
}

void audio_nav(AudioSystem *audio) { play(audio, s_nav, NAV_SAMPLES); }
void audio_confirm(AudioSystem *audio) { play(audio, s_confirm, CONFIRM_SAMPLES); }
void audio_glitch(AudioSystem *audio) { play(audio, s_glitch, GLITCH_SAMPLES); }

void audio_shutdown(AudioSystem *audio)
{
    if (audio->enabled) audsrv_quit();
    audio->enabled = 0;
}
