#include <string.h>
#include <kernel.h>
#include <libpad.h>
#include <loadfile.h>
#include <sifrpc.h>
#include "input.h"

static char s_pad_buf[256] __attribute__((aligned(64)));
static u32 s_prev = 0;
static u32 s_now = 0;
static int s_ready = 0;

int input_init(void)
{
    int ret;

    ret = SifLoadModule("rom0:SIO2MAN", 0, NULL);
    if (ret < 0) return ret;

    ret = SifLoadModule("rom0:PADMAN", 0, NULL);
    if (ret < 0) return ret;

    padInit(0);
    if (padPortOpen(0, 0, s_pad_buf) == 0) return -1;

    padSetMainMode(0, 0, PAD_MMODE_DUALSHOCK, PAD_MMODE_LOCK);
    s_ready = 1;
    return 0;
}

void input_update(InputState *state)
{
    struct padButtonStatus buttons;
    int pad_state;

    memset(state, 0, sizeof(*state));
    if (!s_ready) return;

    pad_state = padGetState(0, 0);
    if (pad_state != PAD_STATE_STABLE && pad_state != PAD_STATE_FINDCTP1) return;

    if (padRead(0, 0, &buttons) > 0) {
        s_prev = s_now;
        s_now = 0xFFFFu ^ buttons.btns;
        state->held = s_now;
        state->pressed = s_now & ~s_prev;
    }
}

void input_shutdown(void)
{
    if (s_ready) {
        padPortClose(0, 0);
        s_ready = 0;
    }
}
