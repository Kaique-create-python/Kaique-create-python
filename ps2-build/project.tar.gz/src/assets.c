#include <stdio.h>
#include <string.h>
#include <gsKit.h>
#include <gsToolkit.h>
#include "assets.h"

static int load_jpeg(GSGLOBAL *gsGlobal, GSTEXTURE *tex, int disc_mode, const char *host_path, const char *disc_path)
{
    int ret;
    memset(tex, 0, sizeof(*tex));
    tex->Delayed = 1;
    tex->Filter = GS_FILTER_LINEAR;
    tex->Vram = GSKIT_ALLOC_ERROR;

    ret = gsKit_texture_jpeg(gsGlobal, tex, disc_mode ? (char *)disc_path : (char *)host_path);
    if (ret < 0 && !disc_mode) {
        ret = gsKit_texture_jpeg(gsGlobal, tex, (char *)disc_path);
    }
    return ret >= 0;
}

void assets_init(Assets *assets, GSGLOBAL *gsGlobal, int disc_mode)
{
    static const char *host_menu[MENU_BG_COUNT] = {
        "host:assets/menu/menu0.jpg",
        "host:assets/menu/menu1.jpg",
        "host:assets/menu/menu2.jpg",
        "host:assets/menu/menu3.jpg",
        "host:assets/menu/menu4.jpg"
    };
    static const char *disc_menu[MENU_BG_COUNT] = {
        "cdrom0:\\MENU\\MENU0.JPG;1",
        "cdrom0:\\MENU\\MENU1.JPG;1",
        "cdrom0:\\MENU\\MENU2.JPG;1",
        "cdrom0:\\MENU\\MENU3.JPG;1",
        "cdrom0:\\MENU\\MENU4.JPG;1"
    };
    int i;

    memset(assets, 0, sizeof(*assets));
    assets->disc_mode = disc_mode;
    assets->boot_ok = load_jpeg(gsGlobal, &assets->boot, disc_mode,
                                "host:assets/menu/boot.jpg",
                                "cdrom0:\\MENU\\BOOT.JPG;1");

    for (i = 0; i < MENU_BG_COUNT; ++i) {
        assets->menu_ok[i] = load_jpeg(gsGlobal, &assets->menu_bg[i], disc_mode,
                                      host_menu[i], disc_menu[i]);
    }
}

void assets_shutdown(Assets *assets, GSGLOBAL *gsGlobal)
{
    int i;
    if (assets->boot_ok) gsKit_TexManager_free(gsGlobal, &assets->boot);
    for (i = 0; i < MENU_BG_COUNT; ++i) {
        if (assets->menu_ok[i]) gsKit_TexManager_free(gsGlobal, &assets->menu_bg[i]);
    }
}

GSTEXTURE *assets_get_menu_bg(Assets *assets, int index)
{
    if (index < 0 || index >= MENU_BG_COUNT) return NULL;
    return assets->menu_ok[index] ? &assets->menu_bg[index] : NULL;
}
