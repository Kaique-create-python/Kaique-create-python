#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAGE="$ROOT/build/iso_stage"
OUT="$ROOT/build/MIDNIGHT_CIRCUIT_PIZZA.iso"

rm -rf "$STAGE"
mkdir -p "$STAGE/MENU" "$STAGE/IRX"
cp "$ROOT/MIDNIGHT.ELF" "$STAGE/SLUS_999.99"
cp "$ROOT/SYSTEM.CNF" "$STAGE/SYSTEM.CNF"
if [[ -f "$ROOT/assets/menu/boot.jpg" ]]; then
  cp "$ROOT/assets/menu/boot.jpg" "$STAGE/MENU/BOOT.JPG"
fi
for i in 0 1 2 3 4; do
  if [[ -f "$ROOT/assets/menu/menu${i}.jpg" ]]; then
    cp "$ROOT/assets/menu/menu${i}.jpg" "$STAGE/MENU/MENU${i}.JPG"
  fi
done

AUDSRV_SRC="${PS2SDK:-}/iop/irx/audsrv.irx"
if [[ -f "$AUDSRV_SRC" ]]; then
  cp "$AUDSRV_SRC" "$STAGE/IRX/AUDSRV.IRX"
else
  echo "warning: audsrv.irx not found; menu audio will be disabled at runtime" >&2
fi

ISO_TOOL=""
command -v genisoimage >/dev/null 2>&1 && ISO_TOOL=genisoimage
if [[ -z "$ISO_TOOL" ]]; then command -v mkisofs >/dev/null 2>&1 && ISO_TOOL=mkisofs; fi
if [[ -z "$ISO_TOOL" ]]; then
  echo "genisoimage/mkisofs is required to build the ISO" >&2
  exit 1
fi

"$ISO_TOOL" -quiet -iso-level 1 -V MIDNIGHT_CIRCUIT -o "$OUT" "$STAGE"

echo "ISO created: $OUT"
