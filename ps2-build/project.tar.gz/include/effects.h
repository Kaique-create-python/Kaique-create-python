#ifndef MIDNIGHT_EFFECTS_H
#define MIDNIGHT_EFFECTS_H

#include "renderer.h"

typedef struct {
    float scanlines;
    float grain;
    float flicker;
    float glitch;
    float vignette;
    float darken;
    u32 rng;
} ScreenEffects;

void effects_init(ScreenEffects *fx);
void effects_update(ScreenEffects *fx, int frame, float intensity);
void effects_render(ScreenEffects *fx, Renderer *renderer);

#endif
