#ifndef MIDNIGHT_RENDERER_H
#define MIDNIGHT_RENDERER_H

#include <gsKit.h>
#include <gsToolkit.h>

typedef struct {
    GSGLOBAL *gs;
    GSFONTM *font;
    int font_ok;
    int frame;
} Renderer;

int renderer_init(Renderer *renderer);
void renderer_begin(Renderer *renderer, u64 clear_color);
void renderer_end(Renderer *renderer);
void renderer_draw_texture(Renderer *renderer, GSTEXTURE *tex, float zoom, float pan_x, float pan_y, u64 tint);
void renderer_rect(Renderer *renderer, float x1, float y1, float x2, float y2, int z, u64 color);
void renderer_text(Renderer *renderer, float x, float y, int z, float scale, u64 color, const char *text);
void renderer_shutdown(Renderer *renderer);

#endif
