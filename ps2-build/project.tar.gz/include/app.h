#ifndef MIDNIGHT_APP_H
#define MIDNIGHT_APP_H

#include <tamtypes.h>

typedef enum {
    SCENE_BOOT = 0,
    SCENE_MENU,
    SCENE_NEW_GAME,
    SCENE_CONTINUE,
    SCENE_NIGHTS,
    SCENE_EXTRAS,
    SCENE_OPTIONS,
    SCENE_CREDITS
} SceneId;

typedef struct {
    SceneId scene;
    SceneId next_scene;
    int running;
    int frame;
    int disc_mode;
} AppState;

#endif
