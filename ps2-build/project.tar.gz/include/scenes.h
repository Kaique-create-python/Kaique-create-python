#ifndef MIDNIGHT_SCENES_H
#define MIDNIGHT_SCENES_H

#include "app.h"
#include "menu.h"

void scenes_update(AppState *app, MenuState *menu, const InputState *input, AudioSystem *audio);
void scenes_render(AppState *app, MenuState *menu, Renderer *renderer, Assets *assets, ScreenEffects *fx);

#endif
