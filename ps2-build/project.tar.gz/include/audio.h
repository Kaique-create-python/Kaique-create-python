#ifndef MIDNIGHT_AUDIO_H
#define MIDNIGHT_AUDIO_H

typedef struct {
    int enabled;
    int disc_mode;
} AudioSystem;

void audio_init(AudioSystem *audio, int disc_mode);
void audio_nav(AudioSystem *audio);
void audio_confirm(AudioSystem *audio);
void audio_glitch(AudioSystem *audio);
void audio_shutdown(AudioSystem *audio);

#endif
