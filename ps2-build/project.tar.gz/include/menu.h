#ifndef MIDNIGHT_MENU_H
#define MIDNIGHT_MENU_H

#include "app.h"
#include "input.h"
#include "renderer.h"
#include "assets.h"
#include "effects.h"
#include "audio.h"

#define MENU_ITEM_COUNT 6

typedef struct {
    int selected;
    int bg_state;
    int bg_timer;
    int bg_next_change;
    int idle_frames;
    int idle_event;
    int idle_timer;
    int transition_timer;
    SceneId transition_target;
    float menu_jitter;
    u32 rng;
} MenuState;

void menu_init(MenuState *menu);
void menu_update(MenuState *menu, AppState *app, const InputState *input, AudioSystem *audio);
void menu_render(MenuState *menu, Renderer *renderer, Assets *assets, ScreenEffects *fx);

#endif
