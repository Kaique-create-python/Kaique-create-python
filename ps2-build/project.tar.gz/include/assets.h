#ifndef MIDNIGHT_ASSETS_H
#define MIDNIGHT_ASSETS_H

#include <gsKit.h>

#define MENU_BG_COUNT 5

typedef struct {
    GSTEXTURE boot;
    GSTEXTURE menu_bg[MENU_BG_COUNT];
    int boot_ok;
    int menu_ok[MENU_BG_COUNT];
    int disc_mode;
} Assets;

void assets_init(Assets *assets, GSGLOBAL *gsGlobal, int disc_mode);
void assets_shutdown(Assets *assets, GSGLOBAL *gsGlobal);
GSTEXTURE *assets_get_menu_bg(Assets *assets, int index);

#endif
