#ifndef MIDNIGHT_INPUT_H
#define MIDNIGHT_INPUT_H

#include <tamtypes.h>

typedef struct {
    u32 held;
    u32 pressed;
} InputState;

int input_init(void);
void input_update(InputState *state);
void input_shutdown(void);

#endif
